import { sql } from 'drizzle-orm';
import { relations } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  boolean,
  integer,
  date,
  pgEnum,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (mandatory for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Enums
export const userRoleEnum = pgEnum('user_role', ['admin', 'team_leader', 'supervisor', 'employee', 'hr', 'client']);
export const taskStatusEnum = pgEnum('task_status', ['todo', 'in_progress', 'done', 'overdue']);
export const attendanceStatusEnum = pgEnum('attendance_status', ['present', 'late', 'absent']);
export const fileVisibilityEnum = pgEnum('file_visibility', ['private', 'team', 'workspace', 'public']);
export const pageVisibilityEnum = pgEnum('page_visibility', ['private', 'team', 'workspace', 'public']);

// Users table (mandatory for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: userRoleEnum("role").notNull().default('employee'),
  teamId: varchar("team_id"),
  workspaceId: varchar("workspace_id"),
  language: varchar("language", { length: 5 }).default('en'),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Workspaces
export const workspaces = pgTable("workspaces", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  slug: varchar("slug").unique().notNull(),
  logoUrl: varchar("logo_url"),
  createdBy: varchar("created_by").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Teams
export const teams = pgTable("teams", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  description: text("description"),
  workspaceId: varchar("workspace_id").notNull(),
  createdBy: varchar("created_by").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Projects
export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  description: text("description"),
  clientId: varchar("client_id"),
  teamId: varchar("team_id").notNull(),
  workspaceId: varchar("workspace_id").notNull(),
  status: varchar("status").default('active'),
  startDate: date("start_date"),
  endDate: date("end_date"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Tasks
export const tasks = pgTable("tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: varchar("title").notNull(),
  description: text("description"),
  assignedTo: varchar("assigned_to").notNull(),
  assignedBy: varchar("assigned_by").notNull(),
  projectId: varchar("project_id"),
  teamId: varchar("team_id"),
  workspaceId: varchar("workspace_id").notNull(),
  status: taskStatusEnum("status").default('todo'),
  priority: varchar("priority").default('medium'),
  dueDate: timestamp("due_date"),
  estimatedMinutes: integer("estimated_minutes"),
  actualMinutes: integer("actual_minutes"),
  startTime: timestamp("start_time"),
  endTime: timestamp("end_time"),
  reminderBreakEvery: integer("reminder_break_every").default(25), // Pomodoro technique
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Attendance
export const attendance = pgTable("attendance", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  workspaceId: varchar("workspace_id").notNull(),
  date: date("date").notNull(),
  checkIn: timestamp("check_in"),
  checkOut: timestamp("check_out"),
  status: attendanceStatusEnum("status").default('present'),
  notes: text("notes"),
  hoursWorked: integer("hours_worked"), // in minutes
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Daily Reports
export const dailyReports = pgTable("daily_reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  workspaceId: varchar("workspace_id").notNull(),
  date: date("date").notNull(),
  content: text("content").notNull(),
  mood: varchar("mood"), // happy, neutral, stressed, etc.
  tasksCompleted: integer("tasks_completed").default(0),
  hoursWorked: integer("hours_worked").default(0), // in minutes
  challenges: text("challenges"),
  achievements: text("achievements"),
  aiSummary: text("ai_summary"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Evaluations
export const evaluations = pgTable("evaluations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  evaluatedBy: varchar("evaluated_by").notNull(),
  workspaceId: varchar("workspace_id").notNull(),
  period: varchar("period").notNull(), // "2024-12", "Q1-2024", etc.
  score: integer("score").notNull(), // 1-100
  tasksCompleted: integer("tasks_completed").default(0),
  attendanceRate: integer("attendance_rate").default(0), // percentage
  reportQuality: integer("report_quality").default(0), // 1-10
  teamwork: integer("teamwork").default(0), // 1-10
  notes: text("notes"),
  generatedByAi: boolean("generated_by_ai").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Pages (Notion-style)
export const pages = pgTable("pages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: varchar("title").notNull(),
  content: jsonb("content"), // Tiptap JSON content
  workspaceId: varchar("workspace_id").notNull(),
  teamId: varchar("team_id"),
  projectId: varchar("project_id"),
  createdBy: varchar("created_by").notNull(),
  visibility: pageVisibilityEnum("visibility").default('private'),
  editors: jsonb("editors"), // array of user IDs
  parentId: varchar("parent_id"), // for nested pages
  position: integer("position").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Files
export const files = pgTable("files", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fileName: varchar("file_name").notNull(),
  fileUrl: varchar("file_url").notNull(),
  fileType: varchar("file_type").notNull(),
  fileSize: integer("file_size"), // in bytes
  uploadedBy: varchar("uploaded_by").notNull(),
  workspaceId: varchar("workspace_id").notNull(),
  linkedToId: varchar("linked_to_id"), // taskId, reportId, pageId, etc.
  linkedToType: varchar("linked_to_type"), // 'task', 'report', 'page', etc.
  visibility: fileVisibilityEnum("visibility").default('private'),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Messages (Chat)
export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  senderId: varchar("sender_id").notNull(),
  workspaceId: varchar("workspace_id").notNull(),
  channelId: varchar("channel_id"), // team, project, or direct message
  channelType: varchar("channel_type").default('team'), // team, project, direct
  content: text("content").notNull(),
  messageType: varchar("message_type").default('text'), // text, image, file
  fileUrl: varchar("file_url"),
  replyTo: varchar("reply_to"), // for threaded conversations
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Notifications
export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  workspaceId: varchar("workspace_id").notNull(),
  title: varchar("title").notNull(),
  message: text("message").notNull(),
  type: varchar("type").notNull(), // task, attendance, report, chat, etc.
  relatedId: varchar("related_id"), // ID of related entity
  relatedType: varchar("related_type"), // type of related entity
  isRead: boolean("is_read").default(false),
  actionUrl: varchar("action_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Timers (for task time tracking)
export const timers = pgTable("timers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  taskId: varchar("task_id").notNull(),
  workspaceId: varchar("workspace_id").notNull(),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time"),
  duration: integer("duration"), // in seconds
  isActive: boolean("is_active").default(true),
  breakCount: integer("break_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ one, many }) => ({
  workspace: one(workspaces, {
    fields: [users.workspaceId],
    references: [workspaces.id],
  }),
  team: one(teams, {
    fields: [users.teamId],
    references: [teams.id],
  }),
  assignedTasks: many(tasks, { relationName: "assignedTo" }),
  createdTasks: many(tasks, { relationName: "assignedBy" }),
  attendance: many(attendance),
  dailyReports: many(dailyReports),
  evaluations: many(evaluations, { relationName: "evaluatedUser" }),
  givenEvaluations: many(evaluations, { relationName: "evaluator" }),
  pages: many(pages),
  files: many(files),
  messages: many(messages),
  notifications: many(notifications),
  timers: many(timers),
}));

export const workspacesRelations = relations(workspaces, ({ one, many }) => ({
  creator: one(users, {
    fields: [workspaces.createdBy],
    references: [users.id],
  }),
  members: many(users),
  teams: many(teams),
  projects: many(projects),
  tasks: many(tasks),
  attendance: many(attendance),
  dailyReports: many(dailyReports),
  evaluations: many(evaluations),
  pages: many(pages),
  files: many(files),
  messages: many(messages),
  notifications: many(notifications),
  timers: many(timers),
}));

export const teamsRelations = relations(teams, ({ one, many }) => ({
  workspace: one(workspaces, {
    fields: [teams.workspaceId],
    references: [workspaces.id],
  }),
  creator: one(users, {
    fields: [teams.createdBy],
    references: [users.id],
  }),
  members: many(users),
  projects: many(projects),
  tasks: many(tasks),
  pages: many(pages),
}));

export const projectsRelations = relations(projects, ({ one, many }) => ({
  workspace: one(workspaces, {
    fields: [projects.workspaceId],
    references: [workspaces.id],
  }),
  team: one(teams, {
    fields: [projects.teamId],
    references: [teams.id],
  }),
  client: one(users, {
    fields: [projects.clientId],
    references: [users.id],
  }),
  tasks: many(tasks),
  pages: many(pages),
}));

export const tasksRelations = relations(tasks, ({ one, many }) => ({
  assignee: one(users, {
    fields: [tasks.assignedTo],
    references: [users.id],
    relationName: "assignedTo",
  }),
  assigner: one(users, {
    fields: [tasks.assignedBy],
    references: [users.id],
    relationName: "assignedBy",
  }),
  project: one(projects, {
    fields: [tasks.projectId],
    references: [projects.id],
  }),
  team: one(teams, {
    fields: [tasks.teamId],
    references: [teams.id],
  }),
  workspace: one(workspaces, {
    fields: [tasks.workspaceId],
    references: [workspaces.id],
  }),
  timers: many(timers),
}));

// Insert schemas
export const upsertUserSchema = createInsertSchema(users).pick({
  id: true,
  email: true,
  firstName: true,
  lastName: true,
  profileImageUrl: true,
});

export const insertWorkspaceSchema = createInsertSchema(workspaces).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTeamSchema = createInsertSchema(teams).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAttendanceSchema = createInsertSchema(attendance).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDailyReportSchema = createInsertSchema(dailyReports).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEvaluationSchema = createInsertSchema(evaluations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPageSchema = createInsertSchema(pages).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertFileSchema = createInsertSchema(files).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
});

export const insertTimerSchema = createInsertSchema(timers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type UpsertUser = z.infer<typeof upsertUserSchema>;
export type User = typeof users.$inferSelect;
export type Workspace = typeof workspaces.$inferSelect;
export type Team = typeof teams.$inferSelect;
export type Project = typeof projects.$inferSelect;
export type Task = typeof tasks.$inferSelect;
export type Attendance = typeof attendance.$inferSelect;
export type DailyReport = typeof dailyReports.$inferSelect;
export type Evaluation = typeof evaluations.$inferSelect;
export type Page = typeof pages.$inferSelect;
export type File = typeof files.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type Timer = typeof timers.$inferSelect;

export type InsertWorkspace = z.infer<typeof insertWorkspaceSchema>;
export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type InsertDailyReport = z.infer<typeof insertDailyReportSchema>;
export type InsertEvaluation = z.infer<typeof insertEvaluationSchema>;
export type InsertPage = z.infer<typeof insertPageSchema>;
export type InsertFile = z.infer<typeof insertFileSchema>;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type InsertTimer = z.infer<typeof insertTimerSchema>;
