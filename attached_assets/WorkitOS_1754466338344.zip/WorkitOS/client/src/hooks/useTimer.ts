import { useState, useEffect, useCallback } from "react";
import type { Timer } from "@shared/schema";

interface UseTimerOptions {
  onComplete?: () => void;
  onTick?: (timeRemaining: number) => void;
  updateInterval?: number;
}

interface UseTimerReturn {
  timeRemaining: number;
  isRunning: boolean;
  progress: number;
  formatTime: (seconds: number) => string;
  start: () => void;
  pause: () => void;
  resume: () => void;
  stop: () => void;
  reset: () => void;
}

export function useTimer(
  timer?: Timer | null,
  options: UseTimerOptions = {}
): UseTimerReturn {
  const { onComplete, onTick, updateInterval = 1000 } = options;
  
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [isRunning, setIsRunning] = useState(false);

  // Calculate initial time remaining based on timer data
  useEffect(() => {
    if (!timer) {
      setTimeRemaining(0);
      setIsRunning(false);
      return;
    }

    const now = Date.now();
    const startTime = new Date(timer.startTime).getTime();
    const elapsed = Math.floor((now - startTime) / 1000);
    
    // If timer has an estimated duration, use it; otherwise use 25 minutes (Pomodoro)
    const totalDuration = timer.estimatedMinutes ? timer.estimatedMinutes * 60 : 25 * 60;
    const remaining = Math.max(0, totalDuration - elapsed);
    
    setTimeRemaining(remaining);
    setIsRunning(timer.isActive && remaining > 0);
  }, [timer]);

  // Timer countdown effect
  useEffect(() => {
    if (!isRunning || timeRemaining <= 0) {
      return;
    }

    const interval = setInterval(() => {
      setTimeRemaining((prev) => {
        const newTime = Math.max(0, prev - 1);
        
        if (onTick) {
          onTick(newTime);
        }
        
        if (newTime === 0) {
          setIsRunning(false);
          if (onComplete) {
            onComplete();
          }
        }
        
        return newTime;
      });
    }, updateInterval);

    return () => clearInterval(interval);
  }, [isRunning, timeRemaining, onComplete, onTick, updateInterval]);

  const formatTime = useCallback((seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    if (hours > 0) {
      return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    
    return `${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }, []);

  const start = useCallback(() => {
    setIsRunning(true);
  }, []);

  const pause = useCallback(() => {
    setIsRunning(false);
  }, []);

  const resume = useCallback(() => {
    if (timeRemaining > 0) {
      setIsRunning(true);
    }
  }, [timeRemaining]);

  const stop = useCallback(() => {
    setIsRunning(false);
    setTimeRemaining(0);
  }, []);

  const reset = useCallback(() => {
    setIsRunning(false);
    if (timer) {
      const totalDuration = timer.estimatedMinutes ? timer.estimatedMinutes * 60 : 25 * 60;
      setTimeRemaining(totalDuration);
    } else {
      setTimeRemaining(0);
    }
  }, [timer]);

  // Calculate progress percentage
  const progress = timer
    ? timeRemaining / ((timer.estimatedMinutes || 25) * 60) * 100
    : 0;

  return {
    timeRemaining,
    isRunning,
    progress: Math.max(0, Math.min(100, progress)),
    formatTime,
    start,
    pause,
    resume,
    stop,
    reset,
  };
}
