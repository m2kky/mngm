import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { GlassCard } from "./glass-card";
import { Button } from "./button";
import { Input } from "./input";
import { ScrollArea } from "./scroll-area";
import { X, Send, Paperclip } from "lucide-react";
import { useWebSocket } from "@/hooks/useWebSocket";
import { cn } from "@/lib/utils";
import type { User, Message } from "@shared/schema";

interface ChatWidgetProps {
  onClose: () => void;
  user: User;
}

export function ChatWidget({ onClose, user }: ChatWidgetProps) {
  const [message, setMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();

  // Use team chat as default channel
  const channelId = user.teamId || user.workspaceId || "general";
  const channelType = "team";

  const { data: messages, isLoading } = useQuery({
    queryKey: ["/api/chat", channelId, channelType],
    enabled: !!channelId,
  });

  const { sendMessage, isConnected } = useWebSocket({
    onMessage: (data) => {
      if (data.type === "chat_message") {
        queryClient.invalidateQueries({
          queryKey: ["/api/chat", channelId, channelType],
        });
      }
    },
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      if (!content.trim() || !user.workspaceId) return;

      await sendMessage({
        type: "chat_message",
        senderId: user.id,
        workspaceId: user.workspaceId,
        channelId,
        channelType,
        content: content.trim(),
      });
    },
    onSuccess: () => {
      setMessage("");
      queryClient.invalidateQueries({
        queryKey: ["/api/chat", channelId, channelType],
      });
    },
  });

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleSendMessage = () => {
    if (message.trim()) {
      sendMessageMutation.mutate(message);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    });
  };

  const isCurrentUser = (senderId: string) => senderId === user.id;

  return (
    <div className="fixed bottom-6 left-6 w-80 h-96 z-40 animate-slide-up">
      <GlassCard className="h-full flex flex-col shadow-2xl">
        {/* Header */}
        <div className="p-4 border-b border-white/20 flex-shrink-0">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-white">Team Chat</h3>
              <div className="flex items-center space-x-2">
                <div className={cn(
                  "w-2 h-2 rounded-full",
                  isConnected ? "bg-success animate-pulse-soft" : "bg-error"
                )}></div>
                <span className="text-xs text-white/60">
                  {isConnected ? "Connected" : "Disconnected"}
                </span>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="text-white/60 hover:text-white transition-colors p-1 h-auto"
              onClick={onClose}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Messages */}
        <ScrollArea className="flex-1 p-4 glass-scrollbar">
          {isLoading ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-white/60">Loading messages...</div>
            </div>
          ) : (
            <div className="space-y-3">
              {messages?.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-white/60">No messages yet</p>
                  <p className="text-white/40 text-xs mt-1">
                    Start the conversation!
                  </p>
                </div>
              ) : (
                messages?.map((msg: Message) => (
                  <div
                    key={msg.id}
                    className={cn(
                      "flex",
                      isCurrentUser(msg.senderId) ? "justify-end" : "justify-start"
                    )}
                  >
                    <div
                      className={cn(
                        "max-w-[80%] rounded-xl p-3 text-sm",
                        isCurrentUser(msg.senderId)
                          ? "bg-primary text-white ml-4"
                          : "glass-dark text-white mr-4"
                      )}
                    >
                      {!isCurrentUser(msg.senderId) && (
                        <div className="text-xs text-primary font-medium mb-1">
                          {msg.senderId.slice(0, 8)}...
                        </div>
                      )}
                      <div className="break-words">{msg.content}</div>
                      <div
                        className={cn(
                          "text-xs mt-1 opacity-70",
                          isCurrentUser(msg.senderId) ? "text-right" : "text-left"
                        )}
                      >
                        {formatTime(msg.createdAt)}
                      </div>
                    </div>
                  </div>
                ))
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </ScrollArea>

        {/* Input */}
        <div className="p-4 border-t border-white/20 flex-shrink-0">
          {isTyping && (
            <div className="text-xs text-white/60 mb-2">Someone is typing...</div>
          )}
          <div className="flex items-center space-x-2">
            <Input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type a message..."
              className="flex-1 glass-dark text-white placeholder-white/50 border-white/20 focus:border-primary/50 focus:ring-primary/20 text-sm"
              disabled={sendMessageMutation.isPending || !isConnected}
            />
            <Button
              variant="ghost"
              size="sm"
              className="glass-dark p-2 rounded-xl hover:bg-white/10 transition-all duration-200 text-white/60 hover:text-white"
              disabled={!message.trim() || sendMessageMutation.isPending || !isConnected}
            >
              <Paperclip className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="glass-dark p-2 rounded-xl hover:bg-white/10 transition-all duration-200"
              onClick={handleSendMessage}
              disabled={!message.trim() || sendMessageMutation.isPending || !isConnected}
            >
              <Send className="w-4 h-4 text-primary" />
            </Button>
          </div>
        </div>
      </GlassCard>
    </div>
  );
}
