import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { GlassCard } from "./glass-card";
import { Button } from "./button";
import { Play, Pause, X } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useTimer } from "@/hooks/useTimer";

export function FloatingTimer() {
  const queryClient = useQueryClient();
  const [isVisible, setIsVisible] = useState(true);
  
  const { data: activeTimer, isLoading } = useQuery({
    queryKey: ["/api/timers/active"],
    refetchInterval: 1000, // Update every second
  });

  const { timeRemaining, isRunning, formatTime } = useTimer(activeTimer);

  const stopTimerMutation = useMutation({
    mutationFn: async (timerId: string) => {
      await apiRequest("POST", `/api/timers/${timerId}/stop`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/timers/active"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
  });

  // Don't show if no active timer or loading
  if (isLoading || !activeTimer || !isVisible) {
    return null;
  }

  const progress = activeTimer.duration ? (timeRemaining / activeTimer.duration) * 100 : 0;
  const circumference = 2 * Math.PI * 45;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  const handleToggleTimer = () => {
    // TODO: Implement pause/resume functionality
    console.log("Timer toggle - pause/resume functionality to be implemented");
  };

  const handleStopTimer = () => {
    if (activeTimer?.id) {
      stopTimerMutation.mutate(activeTimer.id);
    }
  };

  const handleCloseTimer = () => {
    setIsVisible(false);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 animate-fade-in">
      <GlassCard className="p-4 shadow-2xl">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <svg className="w-12 h-12 transform -rotate-90" viewBox="0 0 100 100">
              <circle 
                cx="50" 
                cy="50" 
                r="45" 
                stroke="rgba(255,255,255,0.2)" 
                strokeWidth="6" 
                fill="none"
              />
              <circle 
                cx="50" 
                cy="50" 
                r="45" 
                stroke="#6366f1" 
                strokeWidth="6" 
                fill="none" 
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                className="transition-all duration-1000 ease-linear"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <Button
                variant="ghost"
                size="sm"
                className="w-6 h-6 glass-dark rounded-full flex items-center justify-center hover:bg-white/10 transition-all duration-200 p-0"
                onClick={handleToggleTimer}
              >
                {isRunning ? (
                  <Pause className="w-3 h-3 text-white" />
                ) : (
                  <Play className="w-3 h-3 text-white" />
                )}
              </Button>
            </div>
          </div>
          
          <div className="text-white">
            <p className="text-sm font-semibold">
              Task Timer
            </p>
            <p className="text-xs text-white/70">
              <span>{formatTime(timeRemaining)}</span> remaining
            </p>
          </div>
          
          <div className="flex flex-col space-y-1">
            <Button
              variant="ghost"
              size="sm"
              className="text-white/60 hover:text-white transition-colors p-1 h-auto"
              onClick={handleStopTimer}
              disabled={stopTimerMutation.isPending}
            >
              <Pause className="w-3 h-3" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="text-white/60 hover:text-white transition-colors p-1 h-auto"
              onClick={handleCloseTimer}
            >
              <X className="w-3 h-3" />
            </Button>
          </div>
        </div>
      </GlassCard>
    </div>
  );
}
