import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { GlassCard } from "./glass-card";
import { Button } from "./button";
import { ScrollArea } from "./scroll-area";
import { X, CheckSquare, Clock, FileText, Users, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";
import type { Notification } from "@shared/schema";

interface NotificationPanelProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
}

export function NotificationPanel({ isOpen, onClose, userId }: NotificationPanelProps) {
  const queryClient = useQueryClient();

  const { data: notifications, isLoading } = useQuery({
    queryKey: ["/api/notifications"],
    enabled: !!userId,
  });

  const markAsReadMutation = useMutation({
    mutationFn: async (notificationId: string) => {
      await apiRequest("PUT", `/api/notifications/${notificationId}/read`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
    },
  });

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "task":
        return CheckSquare;
      case "attendance":
        return Clock;
      case "report":
        return FileText;
      case "team":
        return Users;
      default:
        return AlertCircle;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case "task":
        return "bg-primary/20 text-primary";
      case "attendance":
        return "bg-error/20 text-error";
      case "report":
        return "bg-success/20 text-success";
      case "team":
        return "bg-secondary/20 text-secondary";
      default:
        return "bg-warning/20 text-warning";
    }
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    if (hours < 1) return "Just now";
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  };

  const handleNotificationClick = (notification: Notification) => {
    if (!notification.isRead) {
      markAsReadMutation.mutate(notification.id);
    }
    
    // Navigate to related content if actionUrl exists
    if (notification.actionUrl) {
      window.location.href = notification.actionUrl;
    }
  };

  const unreadCount = notifications?.filter((n: Notification) => !n.isRead).length || 0;

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40 transition-opacity duration-300"
          onClick={onClose}
        />
      )}
      
      {/* Panel */}
      <div
        className={cn(
          "fixed top-0 right-0 w-80 h-full z-50 transform transition-transform duration-300 ease-in-out",
          isOpen ? "translate-x-0" : "translate-x-full"
        )}
      >
        <GlassCard variant="dark" className="h-full rounded-none rounded-l-2xl">
          {/* Header */}
          <div className="p-6 border-b border-white/20">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-white">Notifications</h3>
                {unreadCount > 0 && (
                  <p className="text-xs text-white/60 mt-1">
                    {unreadCount} unread notification{unreadCount !== 1 ? 's' : ''}
                  </p>
                )}
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="text-white/60 hover:text-white transition-colors p-1 h-auto"
                onClick={onClose}
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Notifications List */}
          <ScrollArea className="flex-1 glass-scrollbar">
            {isLoading ? (
              <div className="p-6">
                <div className="flex items-center justify-center">
                  <div className="text-white/60">Loading notifications...</div>
                </div>
              </div>
            ) : (
              <div className="p-4 space-y-3">
                {notifications?.length === 0 ? (
                  <div className="text-center py-12">
                    <AlertCircle className="w-12 h-12 text-white/30 mx-auto mb-4" />
                    <p className="text-white/60 mb-2">No notifications</p>
                    <p className="text-white/40 text-sm">
                      You're all caught up!
                    </p>
                  </div>
                ) : (
                  notifications?.map((notification: Notification) => {
                    const Icon = getNotificationIcon(notification.type);
                    const colorClass = getNotificationColor(notification.type);
                    
                    return (
                      <GlassCard
                        key={notification.id}
                        className={cn(
                          "p-4 hover:bg-white/5 transition-all duration-200 cursor-pointer",
                          !notification.isRead && "ring-1 ring-primary/30"
                        )}
                        onClick={() => handleNotificationClick(notification)}
                      >
                        <div className="flex items-start space-x-3">
                          <div className={cn(
                            "flex-shrink-0 w-8 h-8 rounded-xl flex items-center justify-center",
                            colorClass
                          )}>
                            <Icon className="w-4 h-4" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className={cn(
                              "text-sm font-medium text-white",
                              !notification.isRead && "font-semibold"
                            )}>
                              {notification.title}
                            </p>
                            <p className="text-xs text-white/70 mt-1 line-clamp-2">
                              {notification.message}
                            </p>
                            <p className="text-xs text-white/50 mt-2">
                              {formatTime(notification.createdAt)}
                            </p>
                          </div>
                          {!notification.isRead && (
                            <div className="w-2 h-2 rounded-full bg-primary animate-pulse-soft"></div>
                          )}
                        </div>
                      </GlassCard>
                    );
                  })
                )}
              </div>
            )}
          </ScrollArea>

          {/* Footer Actions */}
          {notifications?.length > 0 && (
            <div className="p-4 border-t border-white/20">
              <Button
                variant="ghost"
                size="sm"
                className="w-full text-white/60 hover:text-white transition-colors"
                onClick={() => {
                  // Mark all as read functionality
                  notifications
                    .filter((n: Notification) => !n.isRead)
                    .forEach((n: Notification) => markAsReadMutation.mutate(n.id));
                }}
                disabled={unreadCount === 0 || markAsReadMutation.isPending}
              >
                Mark all as read
              </Button>
            </div>
          )}
        </GlassCard>
      </div>
    </>
  );
}
