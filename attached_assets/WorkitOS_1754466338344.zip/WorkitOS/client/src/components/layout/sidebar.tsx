import { useState } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { GlassCard } from "@/components/ui/glass-card";
import { Button } from "@/components/ui/button";
import { 
  Zap, 
  LayoutDashboard, 
  CheckSquare, 
  Clock, 
  CalendarCheck, 
  FileText, 
  Folder, 
  MessageCircle, 
  Users, 
  ChevronDown,
  Menu,
  X
} from "lucide-react";
import type { User } from "@shared/schema";

interface SidebarProps {
  user: User;
  collapsed: boolean;
  onToggleCollapse: () => void;
  onShowChat: () => void;
}

export function Sidebar({ user, collapsed, onToggleCollapse, onShowChat }: SidebarProps) {
  const [location] = useLocation();
  const [showUserMenu, setShowUserMenu] = useState(false);

  const navigationItems = [
    { href: "/", icon: LayoutDashboard, label: "Dashboard", active: location === "/" },
    { href: "/tasks", icon: CheckSquare, label: "Tasks", badge: "12" },
    { href: "/timer", icon: Clock, label: "Timer" },
    { href: "/attendance", icon: CalendarCheck, label: "Attendance" },
    { href: "/reports", icon: FileText, label: "Reports" },
    { href: "/files", icon: Folder, label: "Files" },
    { href: "/team", icon: Users, label: "Team" },
  ];

  return (
    <aside className={cn(
      "glass rounded-r-2xl m-4 mr-0 transition-all duration-300 ease-in-out",
      collapsed ? "w-16" : "w-64"
    )}>
      <div className="p-6 border-b border-white/20">
        {/* Logo */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 glass rounded-xl flex items-center justify-center">
            <Zap className="w-6 h-6 text-primary" />
          </div>
          {!collapsed && (
            <div>
              <h1 className="text-xl font-bold text-white text-shadow">Workit.OS</h1>
              <p className="text-xs text-white/70">Marketing Hub</p>
            </div>
          )}
        </div>
        
        {/* User Profile */}
        {!collapsed && (
          <div className="mt-4 relative">
            <div className="flex items-center space-x-3 p-3 glass-dark rounded-xl">
              <img 
                src={user.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"} 
                alt={`${user.firstName} ${user.lastName}`}
                className="w-10 h-10 rounded-full object-cover border-2 border-primary/50"
              />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-white truncate">
                  {user.firstName} {user.lastName}
                </p>
                <p className="text-xs text-primary font-medium capitalize">
                  {user.role.replace('_', ' ')}
                </p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="text-white/50 hover:text-white p-1 h-auto"
                onClick={() => setShowUserMenu(!showUserMenu)}
              >
                <ChevronDown className="w-4 h-4" />
              </Button>
            </div>

            {showUserMenu && (
              <div className="absolute top-full left-0 right-0 mt-2 glass-dark rounded-xl p-2 z-50">
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full text-left justify-start text-white/80 hover:text-white"
                  onClick={() => window.location.href = "/api/logout"}
                >
                  Sign Out
                </Button>
              </div>
            )}
          </div>
        )}

        {/* Collapse Toggle */}
        <Button
          variant="ghost"
          size="sm"
          className="absolute top-6 right-6 text-white/50 hover:text-white"
          onClick={onToggleCollapse}
        >
          {collapsed ? <Menu className="w-4 h-4" /> : <X className="w-4 h-4" />}
        </Button>
      </div>

      {/* Navigation */}
      <nav className="p-4 space-y-2">
        {navigationItems.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href} className={cn(
              "flex items-center space-x-3 p-3 rounded-xl hover:bg-white/10 text-white/80 hover:text-white transition-all duration-200 group",
              item.active && "bg-white/10 text-white",
              collapsed && "justify-center"
            )}>
              <Icon className="w-5 h-5 group-hover:scale-110 transition-transform" />
              {!collapsed && (
                <>
                  <span className="font-medium">{item.label}</span>
                  {item.badge && (
                    <span className="ml-auto bg-primary/20 text-primary text-xs px-2 py-1 rounded-full">
                      {item.badge}
                    </span>
                  )}
                </>
              )}
            </Link>
          );
        })}

        {/* Chat Button */}
        <Button
          variant="ghost"
          className={cn(
            "w-full flex items-center space-x-3 p-3 rounded-xl hover:bg-white/10 text-white/80 hover:text-white transition-all duration-200 group justify-start",
            collapsed && "justify-center"
          )}
          onClick={onShowChat}
        >
          <MessageCircle className="w-5 h-5 group-hover:scale-110 transition-transform" />
          {!collapsed && (
            <>
              <span className="font-medium">Chat</span>
              <span className="ml-auto w-2 h-2 bg-success rounded-full animate-pulse"></span>
            </>
          )}
        </Button>
      </nav>

      {/* Workspace Selector */}
      {!collapsed && (
        <div className="p-4 border-t border-white/20 mt-auto">
          <GlassCard className="p-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-white">Creative Agency</p>
                <p className="text-xs text-white/60">8 members</p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="text-white/50 hover:text-white p-1 h-auto"
              >
                <ChevronDown className="w-4 h-4" />
              </Button>
            </div>
          </GlassCard>
        </div>
      )}
    </aside>
  );
}
