import { useState } from "react";
import { Button } from "@/components/ui/button";
import { GlassCard } from "@/components/ui/glass-card";
import { Bell, Settings, Sun, Moon } from "lucide-react";
import type { User } from "@shared/schema";

interface HeaderProps {
  user: User;
  onShowNotifications: () => void;
}

export function Header({ user, onShowNotifications }: HeaderProps) {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [language, setLanguage] = useState('EN');

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
  };

  const toggleLanguage = () => {
    const newLang = language === 'EN' ? 'AR' : 'EN';
    setLanguage(newLang);
    
    if (newLang === 'AR') {
      document.documentElement.setAttribute('lang', 'ar');
      document.documentElement.setAttribute('dir', 'rtl');
    } else {
      document.documentElement.setAttribute('lang', 'en');
      document.documentElement.setAttribute('dir', 'ltr');
    }
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    const firstName = user.firstName || 'there';
    
    if (hour < 12) return `Good morning, ${firstName}! 👋`;
    if (hour < 18) return `Good afternoon, ${firstName}! 👋`;
    return `Good evening, ${firstName}! 👋`;
  };

  return (
    <GlassCard className="p-6 mb-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white text-shadow">
            {getGreeting()}
          </h2>
          <p className="text-white/70 mt-1">
            Here's what's happening with your team today
          </p>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Language Toggle */}
          <Button
            variant="ghost"
            size="sm"
            className="glass-dark p-2 rounded-xl hover:bg-white/10 transition-all duration-200 text-white"
            onClick={toggleLanguage}
          >
            <span className="text-sm font-medium">{language}</span>
          </Button>
          
          {/* Dark Mode Toggle */}
          <Button
            variant="ghost"
            size="sm"
            className="glass-dark p-2 rounded-xl hover:bg-white/10 transition-all duration-200 text-white"
            onClick={toggleDarkMode}
          >
            {isDarkMode ? (
              <Moon className="w-5 h-5" />
            ) : (
              <Sun className="w-5 h-5" />
            )}
          </Button>
          
          {/* Notifications */}
          <Button
            variant="ghost"
            size="sm"
            className="glass-dark p-2 rounded-xl hover:bg-white/10 transition-all duration-200 text-white relative"
            onClick={onShowNotifications}
          >
            <Bell className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-error rounded-full text-xs flex items-center justify-center text-white font-bold">
              3
            </span>
          </Button>
          
          {/* Settings */}
          <Button
            variant="ghost"
            size="sm"
            className="glass-dark p-2 rounded-xl hover:bg-white/10 transition-all duration-200 text-white"
          >
            <Settings className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </GlassCard>
  );
}
