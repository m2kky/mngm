import { GlassCard } from "@/components/ui/glass-card";

interface AttendanceRecord {
  id: string;
  userId: string;
  date: string;
  checkIn?: Date;
  checkOut?: Date;
  status: string;
  hoursWorked?: number;
}

interface AttendanceData {
  total?: number;
  present?: number;
  late?: number;
  absent?: number;
  attendance: AttendanceRecord[];
}

interface AttendanceWidgetProps {
  data?: AttendanceData;
}

export function AttendanceWidget({ data }: AttendanceWidgetProps) {
  const today = new Date().toLocaleDateString('en-US', { 
    month: 'short', 
    day: 'numeric', 
    year: 'numeric' 
  });

  if (!data || !data.attendance) {
    return (
      <div className="glass rounded-2xl p-6 animate-slide-up">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white">Attendance Today</h3>
          <div className="text-xs text-white/60">{today}</div>
        </div>
        <div className="text-center py-8">
          <p className="text-white/60">No attendance data available</p>
        </div>
      </div>
    );
  }

  const total = data.total || data.attendance.length;
  const present = data.present || data.attendance.filter(a => a.status === 'present').length;
  const late = data.late || data.attendance.filter(a => a.status === 'late').length;
  const absent = data.absent || data.attendance.filter(a => a.status === 'absent').length;

  const presentPercentage = total > 0 ? (present / total) * 100 : 0;
  const onTimePercentage = total > 0 ? ((present - late) / total) * 100 : 0;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'present': return 'bg-success';
      case 'late': return 'bg-warning';
      case 'absent': return 'bg-error animate-pulse';
      default: return 'bg-white/40';
    }
  };

  const formatTime = (date?: Date) => {
    if (!date) return 'Not checked in';
    return new Date(date).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  return (
    <div className="glass rounded-2xl p-6 animate-slide-up" style={{ animationDelay: '0.1s' }}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white">Attendance Today</h3>
        <div className="text-xs text-white/60">{today}</div>
      </div>
      
      {/* Attendance Stats */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm text-white/80">Present</span>
          <div className="flex items-center space-x-2">
            <div className="w-20 h-2 bg-white/10 rounded-full overflow-hidden">
              <div 
                className="h-full bg-success rounded-full transition-all duration-500" 
                style={{ width: `${presentPercentage}%` }}
              ></div>
            </div>
            <span className="text-sm font-semibold text-success">
              {present}/{total}
            </span>
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <span className="text-sm text-white/80">On Time</span>
          <div className="flex items-center space-x-2">
            <div className="w-20 h-2 bg-white/10 rounded-full overflow-hidden">
              <div 
                className="h-full bg-primary rounded-full transition-all duration-500" 
                style={{ width: `${onTimePercentage}%` }}
              ></div>
            </div>
            <span className="text-sm font-semibold text-primary">
              {present - late}/{total}
            </span>
          </div>
        </div>
      </div>

      {/* Team Member Status */}
      <div className="mt-6 space-y-2 max-h-32 overflow-y-auto">
        {data.attendance.length === 0 ? (
          <div className="text-center py-4">
            <p className="text-white/60">No attendance records</p>
          </div>
        ) : (
          data.attendance.map((record) => (
            <div key={record.id} className="flex items-center justify-between py-2">
              <div className="flex items-center space-x-2">
                <img 
                  src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=32&h=32" 
                  alt="Team member"
                  className="w-6 h-6 rounded-full object-cover border border-white/20"
                />
                <span className="text-xs text-white/80">
                  User {record.userId.slice(0, 6)}...
                </span>
              </div>
              <div className="flex items-center space-x-1">
                <div className={`w-2 h-2 rounded-full ${getStatusColor(record.status)}`}></div>
                <span className="text-xs text-white/60">
                  {record.status === 'absent' ? 'Absent' : formatTime(record.checkIn)}
                </span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
