import { GlassCard } from "@/components/ui/glass-card";
import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";

interface DailyReport {
  id: string;
  userId: string;
  date: string;
  content: string;
  mood?: string;
  createdAt: Date;
}

interface ReportsData {
  submitted?: number;
  pending?: number;
  reports: DailyReport[];
}

interface ReportsWidgetProps {
  data?: ReportsData;
}

export function ReportsWidget({ data }: ReportsWidgetProps) {
  if (!data) {
    return (
      <div className="glass rounded-2xl p-6 animate-slide-up" style={{ animationDelay: '0.2s' }}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white">Daily Reports</h3>
        </div>
        <div className="text-center py-8">
          <p className="text-white/60">No report data available</p>
        </div>
      </div>
    );
  }

  const submitted = data.submitted || data.reports.length;
  const pending = data.pending || 0;

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    if (hours < 1) return 'Just now';
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  };

  return (
    <div className="glass rounded-2xl p-6 animate-slide-up" style={{ animationDelay: '0.2s' }}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white">Daily Reports</h3>
        <Button
          variant="ghost"
          size="sm"
          className="text-white/60 hover:text-white transition-colors p-1 h-auto"
        >
          <ExternalLink className="w-4 h-4" />
        </Button>
      </div>

      {/* Report Stats */}
      <div className="text-center mb-6">
        <div className="text-3xl font-bold text-white">{submitted}</div>
        <div className="text-sm text-white/60">Reports submitted today</div>
        {pending > 0 && (
          <div className="text-xs text-white/40 mt-1">{pending} pending</div>
        )}
      </div>

      {/* Recent Reports */}
      <div className="space-y-3 max-h-32 overflow-y-auto">
        {data.reports.length === 0 ? (
          <div className="text-center py-4">
            <p className="text-white/60">No reports submitted</p>
          </div>
        ) : (
          data.reports.map((report) => (
            <GlassCard key={report.id} className="p-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <img 
                    src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=32&h=32" 
                    alt="Team member profile"
                    className="w-5 h-5 rounded-full object-cover"
                  />
                  <div>
                    <p className="text-xs font-medium text-white">
                      User {report.userId.slice(0, 6)}...
                    </p>
                    <p className="text-xs text-white/60">
                      {formatTimeAgo(report.createdAt)}
                    </p>
                  </div>
                </div>
                <div className="w-2 h-2 rounded-full bg-success"></div>
              </div>
            </GlassCard>
          ))
        )}
      </div>
    </div>
  );
}
