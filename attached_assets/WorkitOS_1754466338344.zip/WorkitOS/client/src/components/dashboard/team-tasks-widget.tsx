import { GlassCard } from "@/components/ui/glass-card";
import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";

interface Task {
  id: string;
  title: string;
  status: string;
  assignedTo: string;
  dueDate?: Date;
  createdAt: Date;
}

interface TeamTasksData {
  total: number;
  completed: number;
  inProgress: number;
  overdue: number;
  tasks: Task[];
}

interface TeamTasksWidgetProps {
  data?: TeamTasksData;
}

export function TeamTasksWidget({ data }: TeamTasksWidgetProps) {
  if (!data) {
    return (
      <div className="md:col-span-2 glass rounded-2xl p-6 animate-slide-up">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white">Tasks Overview</h3>
        </div>
        <div className="text-center py-8">
          <p className="text-white/60">No task data available</p>
        </div>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'done': return 'text-success';
      case 'in_progress': return 'text-warning';
      case 'overdue': return 'text-error';
      default: return 'text-white/80';
    }
  };

  const getStatusDot = (status: string) => {
    switch (status) {
      case 'done': return 'bg-success';
      case 'in_progress': return 'bg-warning';
      case 'overdue': return 'bg-error animate-pulse';
      default: return 'bg-white/40';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'done': return 'Done';
      case 'in_progress': return 'In Progress';
      case 'overdue': return 'Overdue';
      case 'todo': return 'To Do';
      default: return status;
    }
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    if (hours < 1) return 'Just now';
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  };

  return (
    <div className="md:col-span-2 glass rounded-2xl p-6 animate-slide-up">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white">Tasks Overview</h3>
        <Button
          variant="ghost"
          size="sm"
          className="text-white/60 hover:text-white transition-colors p-1 h-auto"
        >
          <ExternalLink className="w-4 h-4" />
        </Button>
      </div>
      
      {/* Task Progress Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="text-center">
          <div className="text-2xl font-bold text-success">{data.completed}</div>
          <div className="text-xs text-white/60">Completed</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-warning">{data.inProgress}</div>
          <div className="text-xs text-white/60">In Progress</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-error">{data.overdue}</div>
          <div className="text-xs text-white/60">Overdue</div>
        </div>
      </div>

      {/* Recent Tasks List */}
      <div className="space-y-3 max-h-64 overflow-y-auto">
        {data.tasks.length === 0 ? (
          <div className="text-center py-4">
            <p className="text-white/60">No tasks found</p>
          </div>
        ) : (
          data.tasks.map((task) => (
            <GlassCard key={task.id} className="p-4 hover:bg-white/5 transition-all duration-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-2 h-2 rounded-full ${getStatusDot(task.status)}`}></div>
                  <div>
                    <p className="text-sm font-medium text-white">{task.title}</p>
                    <p className="text-xs text-white/60">Assigned to {task.assignedTo}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-white/60">
                    {task.dueDate ? `Due: ${formatTimeAgo(task.dueDate)}` : formatTimeAgo(task.createdAt)}
                  </span>
                  <span className={`px-2 py-1 ${getStatusColor(task.status)}/20 ${getStatusColor(task.status)} text-xs rounded-full`}>
                    {getStatusLabel(task.status)}
                  </span>
                </div>
              </div>
            </GlassCard>
          ))
        )}
      </div>
    </div>
  );
}
