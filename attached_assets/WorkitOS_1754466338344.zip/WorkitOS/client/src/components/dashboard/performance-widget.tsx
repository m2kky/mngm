import { GlassCard } from "@/components/ui/glass-card";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, Target, Clock, Star } from "lucide-react";

interface PerformanceMetrics {
  productivity: number;
  tasksCompleted: number;
  avgHours: number;
  satisfaction: number;
}

interface PerformanceWidgetProps {
  data?: PerformanceMetrics;
}

export function PerformanceWidget({ data }: PerformanceWidgetProps) {
  // Default metrics - in real implementation, this would come from props
  const performanceData = data || {
    productivity: 87,
    tasksCompleted: 92,
    avgHours: 7.2,
    satisfaction: 4.8,
  };

  const metrics = [
    {
      icon: TrendingUp,
      label: "الإنتاجية",
      value: performanceData.productivity,
      unit: "%",
      color: "text-success",
      bgColor: "bg-success/20",
    },
    {
      icon: Target,
      label: "إنجاز المهام",
      value: performanceData.tasksCompleted,
      unit: "%",
      color: "text-primary",
      bgColor: "bg-primary/20",
    },
    {
      icon: Clock,
      label: "متوسط الساعات",
      value: performanceData.avgHours,
      unit: "س",
      color: "text-warning",
      bgColor: "bg-warning/20",
    },
    {
      icon: Star,
      label: "الرضا",
      value: performanceData.satisfaction,
      unit: "/5",
      color: "text-accent",
      bgColor: "bg-accent/20",
    },
  ];

  return (
    <GlassCard className="p-6 animate-slide-up" style={{ animationDelay: '0.4s' }}>
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-white">أداء الفريق</h3>
        <div className="text-xs text-white/60">هذا الأسبوع</div>
      </div>

      <div className="space-y-4">
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          const percentage = metric.unit === "%" ? metric.value : (metric.value / (metric.unit === "/5" ? 5 : 10)) * 100;
          
          return (
            <div key={index} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2 rtl:space-x-reverse">
                  <div className={`p-2 rounded-lg ${metric.bgColor}`}>
                    <Icon className={`w-4 h-4 ${metric.color}`} />
                  </div>
                  <span className="text-sm text-white/80">{metric.label}</span>
                </div>
                <span className={`text-sm font-semibold ${metric.color}`}>
                  {metric.value}{metric.unit}
                </span>
              </div>
              
              <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all duration-1000 ease-out ${
                    metric.color.replace('text-', 'bg-')
                  }`}
                  style={{ 
                    width: `${Math.min(percentage, 100)}%`,
                    animationDelay: `${index * 0.1 + 0.5}s`
                  }}
                ></div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Performance Summary */}
      <div className="mt-6 pt-4 border-t border-white/20">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-white/80">التقييم الإجمالي</p>
            <p className="text-xs text-white/60">بناءً على الأداء الحالي</p>
          </div>
          <div className="text-right">
            <div className="text-xl font-bold text-success">
              {Math.round((performanceData.productivity + performanceData.tasksCompleted) / 2)}%
            </div>
            <div className="text-xs text-white/60">ممتاز</div>
          </div>
        </div>

        {/* Performance trend indicator */}
        <div className="mt-3 flex items-center space-x-2 rtl:space-x-reverse">
          <TrendingUp className="w-4 h-4 text-success" />
          <span className="text-xs text-success">
            +5% من الأسبوع الماضي
          </span>
        </div>
      </div>
    </GlassCard>
  );
}