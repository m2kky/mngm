import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { GlassCard } from "@/components/ui/glass-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Plus, 
  Clock,
  FileText,
  CheckSquare,
  CalendarCheck,
  MessageCircle
} from "lucide-react";

interface QuickActionsWidgetProps {
  role: string;
}

export function QuickActionsWidget({ role }: QuickActionsWidgetProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showTaskDialog, setShowTaskDialog] = useState(false);
  const [showReportDialog, setShowReportDialog] = useState(false);

  // Check-in mutation
  const checkInMutation = useMutation({
    mutationFn: () => apiRequest('/api/attendance/check-in', {
      method: 'POST',
      body: JSON.stringify({}),
    }),
    onSuccess: () => {
      toast({
        title: "تم تسجيل الحضور",
        description: "تم تسجيل حضورك بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في تسجيل الحضور",
        variant: "destructive",
      });
    },
  });

  // Check-out mutation
  const checkOutMutation = useMutation({
    mutationFn: () => apiRequest('/api/attendance/check-out', {
      method: 'POST',
      body: JSON.stringify({}),
    }),
    onSuccess: () => {
      toast({
        title: "تم تسجيل الانصراف",
        description: "تم تسجيل انصرافك بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في تسجيل الانصراف",
        variant: "destructive",
      });
    },
  });

  // Create task mutation
  const createTaskMutation = useMutation({
    mutationFn: (taskData: any) => apiRequest('/api/tasks', {
      method: 'POST',
      body: JSON.stringify(taskData),
    }),
    onSuccess: () => {
      toast({
        title: "تمت إضافة المهمة",
        description: "تم إنشاء المهمة بنجاح",
      });
      setShowTaskDialog(false);
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في إنشاء المهمة",
        variant: "destructive",
      });
    },
  });

  // Submit report mutation
  const submitReportMutation = useMutation({
    mutationFn: (reportData: any) => apiRequest('/api/reports', {
      method: 'POST',
      body: JSON.stringify(reportData),
    }),
    onSuccess: () => {
      toast({
        title: "تم إرسال التقرير",
        description: "تم إرسال تقريرك اليومي بنجاح",
      });
      setShowReportDialog(false);
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في إرسال التقرير",
        variant: "destructive",
      });
    },
  });

  const handleCreateTask = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const taskData = {
      title: formData.get('title'),
      description: formData.get('description'),
      assignedTo: formData.get('assignedTo'),
      priority: formData.get('priority'),
      estimatedMinutes: parseInt(formData.get('estimatedMinutes') as string) || 30,
    };
    createTaskMutation.mutate(taskData);
  };

  const handleSubmitReport = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const reportData = {
      content: formData.get('content'),
      mood: formData.get('mood'),
      tasksCompleted: parseInt(formData.get('tasksCompleted') as string) || 0,
      hoursWorked: parseInt(formData.get('hoursWorked') as string) || 0,
      challenges: formData.get('challenges'),
      achievements: formData.get('achievements'),
    };
    submitReportMutation.mutate(reportData);
  };

  const getQuickActions = () => {
    const baseActions = [
      {
        icon: CalendarCheck,
        label: "تسجيل حضور",
        action: () => checkInMutation.mutate(),
        color: "bg-success",
        loading: checkInMutation.isPending,
      },
      {
        icon: Clock,
        label: "تسجيل انصراف",
        action: () => checkOutMutation.mutate(),
        color: "bg-warning",
        loading: checkOutMutation.isPending,
      },
      {
        icon: FileText,
        label: "تقرير يومي",
        action: () => setShowReportDialog(true),
        color: "bg-primary",
      },
    ];

    if (role === 'team_leader' || role === 'supervisor') {
      baseActions.unshift({
        icon: Plus,
        label: "مهمة جديدة",
        action: () => setShowTaskDialog(true),
        color: "bg-accent",
      });
    }

    return baseActions;
  };

  return (
    <>
      <GlassCard className="p-6 animate-slide-up" style={{ animationDelay: '0.3s' }}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white">إجراءات سريعة</h3>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {getQuickActions().map((action, index) => {
            const Icon = action.icon;
            return (
              <Button
                key={index}
                variant="ghost"
                className={`h-auto p-4 flex flex-col items-center space-y-2 ${action.color}/20 border border-white/20 hover:${action.color}/30 transition-all duration-200`}
                onClick={action.action}
                disabled={action.loading}
              >
                <Icon className="w-6 h-6 text-white" />
                <span className="text-xs text-white/80 text-center font-medium">
                  {action.label}
                </span>
              </Button>
            );
          })}
        </div>
      </GlassCard>

      {/* Create Task Dialog */}
      <Dialog open={showTaskDialog} onOpenChange={setShowTaskDialog}>
        <DialogContent className="glass border-white/20">
          <DialogHeader>
            <DialogTitle className="text-white">إنشاء مهمة جديدة</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleCreateTask} className="space-y-4">
            <div>
              <Label htmlFor="title" className="text-white">عنوان المهمة</Label>
              <Input
                id="title"
                name="title"
                placeholder="أدخل عنوان المهمة"
                className="glass border-white/20 text-white placeholder:text-white/50"
                required
              />
            </div>
            <div>
              <Label htmlFor="description" className="text-white">الوصف</Label>
              <Textarea
                id="description"
                name="description"
                placeholder="تفاصيل المهمة"
                className="glass border-white/20 text-white placeholder:text-white/50"
                rows={3}
              />
            </div>
            <div>
              <Label htmlFor="assignedTo" className="text-white">معرف المستخدم المطلوب</Label>
              <Input
                id="assignedTo"
                name="assignedTo"
                placeholder="User ID"
                className="glass border-white/20 text-white placeholder:text-white/50"
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="priority" className="text-white">الأولوية</Label>
                <Select name="priority" defaultValue="medium">
                  <SelectTrigger className="glass border-white/20 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">منخفضة</SelectItem>
                    <SelectItem value="medium">متوسطة</SelectItem>
                    <SelectItem value="high">عالية</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="estimatedMinutes" className="text-white">الوقت المقدر (دقيقة)</Label>
                <Input
                  id="estimatedMinutes"
                  name="estimatedMinutes"
                  type="number"
                  placeholder="30"
                  className="glass border-white/20 text-white placeholder:text-white/50"
                />
              </div>
            </div>
            <div className="flex justify-end space-x-2">
              <Button
                type="button"
                variant="ghost"
                onClick={() => setShowTaskDialog(false)}
                className="text-white/80 hover:text-white"
              >
                إلغاء
              </Button>
              <Button
                type="submit"
                className="bg-accent hover:bg-accent/80"
                disabled={createTaskMutation.isPending}
              >
                {createTaskMutation.isPending ? "جارٍ الإنشاء..." : "إنشاء المهمة"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Submit Report Dialog */}
      <Dialog open={showReportDialog} onOpenChange={setShowReportDialog}>
        <DialogContent className="glass border-white/20">
          <DialogHeader>
            <DialogTitle className="text-white">التقرير اليومي</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmitReport} className="space-y-4">
            <div>
              <Label htmlFor="content" className="text-white">محتوى التقرير</Label>
              <Textarea
                id="content"
                name="content"
                placeholder="اكتب تقريرك اليومي هنا..."
                className="glass border-white/20 text-white placeholder:text-white/50"
                rows={4}
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="mood" className="text-white">المزاج</Label>
                <Select name="mood" defaultValue="neutral">
                  <SelectTrigger className="glass border-white/20 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="happy">سعيد</SelectItem>
                    <SelectItem value="neutral">عادي</SelectItem>
                    <SelectItem value="stressed">متوتر</SelectItem>
                    <SelectItem value="excited">متحمس</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="tasksCompleted" className="text-white">المهام المكتملة</Label>
                <Input
                  id="tasksCompleted"
                  name="tasksCompleted"
                  type="number"
                  placeholder="0"
                  className="glass border-white/20 text-white placeholder:text-white/50"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="hoursWorked" className="text-white">ساعات العمل (دقيقة)</Label>
              <Input
                id="hoursWorked"
                name="hoursWorked"
                type="number"
                placeholder="480"
                className="glass border-white/20 text-white placeholder:text-white/50"
              />
            </div>
            <div>
              <Label htmlFor="achievements" className="text-white">الإنجازات</Label>
              <Textarea
                id="achievements"
                name="achievements"
                placeholder="ما الذي أنجزته اليوم؟"
                className="glass border-white/20 text-white placeholder:text-white/50"
                rows={2}
              />
            </div>
            <div>
              <Label htmlFor="challenges" className="text-white">التحديات</Label>
              <Textarea
                id="challenges"
                name="challenges"
                placeholder="ما التحديات التي واجهتها؟"
                className="glass border-white/20 text-white placeholder:text-white/50"
                rows={2}
              />
            </div>
            <div className="flex justify-end space-x-2">
              <Button
                type="button"
                variant="ghost"
                onClick={() => setShowReportDialog(false)}
                className="text-white/80 hover:text-white"
              >
                إلغاء
              </Button>
              <Button
                type="submit"
                className="bg-primary hover:bg-primary/80"
                disabled={submitReportMutation.isPending}
              >
                {submitReportMutation.isPending ? "جارٍ الإرسال..." : "إرسال التقرير"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}