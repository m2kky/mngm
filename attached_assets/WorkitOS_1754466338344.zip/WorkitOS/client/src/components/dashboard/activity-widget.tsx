import { GlassCard } from "@/components/ui/glass-card";
import { CheckCircle, AlertCircle, Clock, User } from "lucide-react";

interface ActivityItem {
  id: string;
  user: string;
  action: string;
  target?: string;
  time: string;
  type: 'success' | 'warning' | 'error' | 'primary' | 'secondary';
  avatar?: string | null;
}

interface ActivityWidgetProps {
  activities?: ActivityItem[];
}

export function ActivityWidget({ activities }: ActivityWidgetProps) {
  // Default activity data - in real app this would come from props
  const recentActivity: ActivityItem[] = activities || [
    {
      id: '1',
      user: 'سارة أحمد',
      action: 'أكملت مهمة',
      target: 'تصميم الصفحة الرئيسية',
      time: 'منذ ساعتين',
      type: 'success',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=32&h=32'
    },
    {
      id: '2',
      user: 'محمد علي',
      action: 'أرسل التقرير اليومي لـ',
      target: '28 ديسمبر',
      time: 'منذ 3 ساعات',
      type: 'primary',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=32&h=32'
    },
    {
      id: '3',
      user: 'ليلى محمود',
      action: 'تأخر في تسجيل الحضور لـ',
      target: 'اليوم',
      time: 'منذ 5 ساعات',
      type: 'warning',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=32&h=32'
    },
    {
      id: '4',
      user: 'أحمد خالد',
      action: 'انضم إلى مساحة العمل',
      time: 'منذ يوم واحد',
      type: 'secondary',
      avatar: null
    }
  ];

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="w-4 h-4 text-success" />;
      case 'warning':
        return <AlertCircle className="w-4 h-4 text-warning" />;
      case 'error':
        return <AlertCircle className="w-4 h-4 text-error" />;
      case 'primary':
        return <Clock className="w-4 h-4 text-primary" />;
      default:
        return <User className="w-4 h-4 text-white/60" />;
    }
  };

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'success':
        return 'border-success/30 bg-success/5';
      case 'warning':
        return 'border-warning/30 bg-warning/5';
      case 'error':
        return 'border-error/30 bg-error/5';
      case 'primary':
        return 'border-primary/30 bg-primary/5';
      default:
        return 'border-white/20 bg-white/5';
    }
  };

  return (
    <GlassCard className="p-6 animate-slide-up" style={{ animationDelay: '0.5s' }}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white">النشاط الأخير</h3>
        <div className="text-xs text-white/60">اليوم</div>
      </div>

      <div className="space-y-3 max-h-64 overflow-y-auto">
        {recentActivity.map((activity, index) => (
          <div
            key={activity.id}
            className={`flex items-start space-x-3 rtl:space-x-reverse p-3 rounded-xl border transition-all duration-200 hover:scale-[1.02] ${getActivityColor(activity.type)}`}
            style={{ animationDelay: `${index * 0.1 + 0.6}s` }}
          >
            {/* Avatar */}
            <div className="flex-shrink-0">
              {activity.avatar ? (
                <img
                  src={activity.avatar}
                  alt={activity.user}
                  className="w-8 h-8 rounded-full object-cover border-2 border-white/20"
                />
              ) : (
                <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
                  <User className="w-4 h-4 text-white/60" />
                </div>
              )}
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <p className="text-sm text-white/90">
                    <span className="font-medium">{activity.user}</span>
                    {' '}
                    <span className="text-white/70">{activity.action}</span>
                    {activity.target && (
                      <>
                        {' '}
                        <span className="font-medium text-white/90">{activity.target}</span>
                      </>
                    )}
                  </p>
                  <p className="text-xs text-white/50 mt-1">{activity.time}</p>
                </div>
                <div className="flex-shrink-0 ml-2 rtl:mr-2">
                  {getActivityIcon(activity.type)}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Activity Summary */}
      <div className="mt-4 pt-4 border-t border-white/20">
        <div className="flex items-center justify-between text-sm">
          <span className="text-white/70">النشاط اليوم</span>
          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            <div className="flex items-center space-x-1 rtl:space-x-reverse">
              <CheckCircle className="w-4 h-4 text-success" />
              <span className="text-success">5</span>
            </div>
            <div className="flex items-center space-x-1 rtl:space-x-reverse">
              <AlertCircle className="w-4 h-4 text-warning" />
              <span className="text-warning">2</span>
            </div>
            <div className="flex items-center space-x-1 rtl:space-x-reverse">
              <User className="w-4 h-4 text-primary" />
              <span className="text-primary">12</span>
            </div>
          </div>
        </div>
      </div>
    </GlassCard>
  );
}