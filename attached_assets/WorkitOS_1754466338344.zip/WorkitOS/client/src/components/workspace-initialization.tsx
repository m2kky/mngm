import { useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";

export function WorkspaceInitialization() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const initializeWorkspaceMutation = useMutation({
    mutationFn: () => apiRequest('/api/initialize-workspace', {
      method: 'POST',
      body: JSON.stringify({}),
    }),
    onSuccess: () => {
      // Refresh user data and dashboard
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
  });

  useEffect(() => {
    // Initialize workspace for new users who don't have one
    if (user && !user.workspaceId && !initializeWorkspaceMutation.isPending) {
      initializeWorkspaceMutation.mutate();
    }
  }, [user, initializeWorkspaceMutation]);

  return null; // This is a background component
}