// API endpoints
export const API_ENDPOINTS = {
  AUTH: {
    USER: '/api/auth/user',
    LOGIN: '/api/login',
    LOGOUT: '/api/logout',
  },
  DASHBOARD: '/api/dashboard',
  TASKS: {
    BASE: '/api/tasks',
    MY: '/api/tasks/my',
    STATUS: (id: string) => `/api/tasks/${id}/status`,
  },
  ATTENDANCE: {
    CHECK_IN: '/api/attendance/check-in',
    CHECK_OUT: '/api/attendance/check-out',
  },
  REPORTS: '/api/reports',
  TIMERS: {
    START: '/api/timers/start',
    STOP: (id: string) => `/api/timers/${id}/stop`,
    ACTIVE: '/api/timers/active',
  },
  CHAT: (channelId: string, channelType: string) => `/api/chat/${channelId}/${channelType}`,
  NOTIFICATIONS: {
    BASE: '/api/notifications',
    READ: (id: string) => `/api/notifications/${id}/read`,
  },
} as const;

// WebSocket event types
export const WS_EVENTS = {
  CHAT_MESSAGE: 'chat_message',
  TASK_UPDATE: 'task_update',
  ATTENDANCE_UPDATE: 'attendance_update',
  NOTIFICATION: 'notification',
  TIMER_UPDATE: 'timer_update',
} as const;

// User roles
export const USER_ROLES = {
  ADMIN: 'admin',
  TEAM_LEADER: 'team_leader',
  SUPERVISOR: 'supervisor',
  EMPLOYEE: 'employee',
  HR: 'hr',
  CLIENT: 'client',
} as const;

// Task statuses
export const TASK_STATUSES = {
  TODO: 'todo',
  IN_PROGRESS: 'in_progress',
  DONE: 'done',
  OVERDUE: 'overdue',
} as const;

// Attendance statuses
export const ATTENDANCE_STATUSES = {
  PRESENT: 'present',
  LATE: 'late',
  ABSENT: 'absent',
} as const;

// File visibility levels
export const FILE_VISIBILITY = {
  PRIVATE: 'private',
  TEAM: 'team',
  WORKSPACE: 'workspace',
  PUBLIC: 'public',
} as const;

// Notification types
export const NOTIFICATION_TYPES = {
  TASK: 'task',
  ATTENDANCE: 'attendance',
  REPORT: 'report',
  CHAT: 'chat',
  TEAM: 'team',
  SYSTEM: 'system',
} as const;

// Timer defaults
export const TIMER_DEFAULTS = {
  POMODORO_MINUTES: 25,
  SHORT_BREAK_MINUTES: 5,
  LONG_BREAK_MINUTES: 15,
  BREAK_REMINDER_INTERVAL: 25, // minutes
} as const;

// UI constants
export const UI_CONSTANTS = {
  SIDEBAR_WIDTH: {
    EXPANDED: 256, // w-64 in pixels
    COLLAPSED: 64, // w-16 in pixels
  },
  MOBILE_BREAKPOINT: 768,
  ANIMATION_DURATION: {
    FAST: 200,
    NORMAL: 300,
    SLOW: 500,
  },
  QUERY_STALE_TIME: {
    SHORT: 30000, // 30 seconds
    MEDIUM: 300000, // 5 minutes
    LONG: 600000, // 10 minutes
  },
} as const;

// Language codes
export const LANGUAGES = {
  ENGLISH: 'en',
  ARABIC: 'ar',
} as const;

// Theme modes
export const THEME_MODES = {
  LIGHT: 'light',
  DARK: 'dark',
  SYSTEM: 'system',
} as const;

// Color palette for status indicators
export const STATUS_COLORS = {
  SUCCESS: 'hsl(142, 71%, 45%)',
  WARNING: 'hsl(38, 92%, 50%)',
  ERROR: 'hsl(0, 72%, 51%)',
  PRIMARY: 'hsl(239, 84%, 67%)',
  SECONDARY: 'hsl(261, 51%, 51%)',
  INFO: 'hsl(207, 90%, 54%)',
} as const;

// Glassmorphism settings
export const GLASS_SETTINGS = {
  BLUR: {
    LIGHT: 'blur(8px)',
    MEDIUM: 'blur(10px)',
    HEAVY: 'blur(16px)',
  },
  OPACITY: {
    LIGHT: 0.1,
    MEDIUM: 0.2,
    HEAVY: 0.3,
  },
} as const;

// Performance monitoring
export const PERFORMANCE = {
  DEBOUNCE_DELAY: 300,
  THROTTLE_DELAY: 100,
  PAGINATION_SIZE: 20,
  MAX_FILE_SIZE: 10 * 1024 * 1024, // 10MB
  SUPPORTED_FILE_TYPES: [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
    'application/pdf',
    'text/plain',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  ],
} as const;

// Error messages
export const ERROR_MESSAGES = {
  NETWORK_ERROR: 'Network error. Please check your connection and try again.',
  UNAUTHORIZED: 'You are not authorized to perform this action.',
  FORBIDDEN: 'Access denied. You do not have permission to access this resource.',
  NOT_FOUND: 'The requested resource was not found.',
  SERVER_ERROR: 'An unexpected error occurred. Please try again later.',
  VALIDATION_ERROR: 'Please check your input and try again.',
  FILE_TOO_LARGE: 'File size exceeds the maximum allowed limit.',
  UNSUPPORTED_FILE_TYPE: 'This file type is not supported.',
  CONNECTION_LOST: 'Connection lost. Attempting to reconnect...',
} as const;

export type UserRole = typeof USER_ROLES[keyof typeof USER_ROLES];
export type TaskStatus = typeof TASK_STATUSES[keyof typeof TASK_STATUSES];
export type AttendanceStatus = typeof ATTENDANCE_STATUSES[keyof typeof ATTENDANCE_STATUSES];
export type NotificationType = typeof NOTIFICATION_TYPES[keyof typeof NOTIFICATION_TYPES];
export type Language = typeof LANGUAGES[keyof typeof LANGUAGES];
export type ThemeMode = typeof THEME_MODES[keyof typeof THEME_MODES];
