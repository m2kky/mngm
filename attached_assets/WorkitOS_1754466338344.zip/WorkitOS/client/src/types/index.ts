import type { 
  User, 
  Task, 
  Attendance, 
  DailyReport, 
  Message, 
  Notification,
  Timer,
  Workspace,
  Team,
  Project 
} from "@shared/schema";

// Dashboard data types
export interface DashboardData {
  user: User;
  role: string;
  workspaceId: string;
  teamTasks?: TaskOverview;
  personalTasks?: TaskOverview;
  teamAttendance?: AttendanceOverview;
  attendance?: Attendance;
  teamReports?: ReportOverview;
  dailyReport?: DailyReport;
  activeTimer?: Timer;
  notifications?: Notification[];
}

export interface TaskOverview {
  total: number;
  completed: number;
  inProgress: number;
  overdue: number;
  tasks: Task[];
}

export interface AttendanceOverview {
  total: number;
  present: number;
  late: number;
  absent: number;
  attendance: Attendance[];
}

export interface ReportOverview {
  submitted: number;
  pending: number;
  reports: DailyReport[];
}

// WebSocket message types
export interface WebSocketMessage {
  type: string;
  data?: any;
  timestamp?: number;
}

export interface ChatMessage extends WebSocketMessage {
  type: 'chat_message';
  message: Message;
}

export interface TaskUpdateMessage extends WebSocketMessage {
  type: 'task_update';
  task: Task;
  action: 'created' | 'updated' | 'deleted' | 'status_changed';
}

export interface AttendanceUpdateMessage extends WebSocketMessage {
  type: 'attendance_update';
  attendance: Attendance;
  action: 'check_in' | 'check_out';
}

export interface NotificationMessage extends WebSocketMessage {
  type: 'notification';
  notification: Notification;
}

export interface TimerUpdateMessage extends WebSocketMessage {
  type: 'timer_update';
  timer: Timer;
  action: 'started' | 'stopped' | 'paused' | 'resumed';
}

// Form data types
export interface CreateTaskData {
  title: string;
  description?: string;
  assignedTo: string;
  projectId?: string;
  dueDate?: Date;
  estimatedMinutes?: number;
  priority?: 'low' | 'medium' | 'high';
}

export interface SubmitReportData {
  content: string;
  mood?: string;
  tasksCompleted?: number;
  hoursWorked?: number;
  challenges?: string;
  achievements?: string;
}

export interface StartTimerData {
  taskId: string;
  estimatedMinutes?: number;
}

export interface SendMessageData {
  channelId: string;
  channelType: 'team' | 'project' | 'direct';
  content: string;
  messageType?: 'text' | 'image' | 'file';
  fileUrl?: string;
}

// UI component prop types
export interface SidebarProps {
  user: User;
  collapsed: boolean;
  onToggleCollapse: () => void;
  onShowChat: () => void;
}

export interface HeaderProps {
  user: User;
  onShowNotifications: () => void;
}

export interface FloatingTimerProps {
  timer?: Timer;
  onStop?: () => void;
  onPause?: () => void;
  onResume?: () => void;
}

export interface ChatWidgetProps {
  onClose: () => void;
  user: User;
  channelId?: string;
  channelType?: 'team' | 'project' | 'direct';
}

export interface NotificationPanelProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
}

// Widget data prop types
export interface TeamTasksWidgetProps {
  data?: TaskOverview;
}

export interface AttendanceWidgetProps {
  data?: AttendanceOverview | { attendance: Attendance[] };
}

export interface ReportsWidgetProps {
  data?: ReportOverview | { reports: DailyReport[] };
}

export interface QuickActionsWidgetProps {
  role: string;
}

// Performance analytics types
export interface PerformanceMetrics {
  productivity: number;
  tasksCompleted: number;
  avgHours: number;
  satisfaction: number;
}

export interface TeamMemberPerformance {
  id: string;
  name: string;
  role: string;
  tasksCompleted: number;
  efficiency: number;
  score: number;
  avatar?: string;
}

// Activity feed types
export interface ActivityItem {
  id: string;
  user: string;
  action: string;
  target?: string;
  time: string;
  type: 'success' | 'primary' | 'error' | 'secondary';
  avatar?: string;
}

// File handling types
export interface FileUpload {
  file: File;
  linkedToId?: string;
  linkedToType?: 'task' | 'report' | 'page';
  visibility?: 'private' | 'team' | 'workspace' | 'public';
}

export interface FilePreview {
  id: string;
  fileName: string;
  fileUrl: string;
  fileType: string;
  fileSize: number;
  uploadedBy: string;
  createdAt: Date;
}

// Theme and language types
export interface ThemeConfig {
  mode: 'light' | 'dark' | 'system';
  primaryColor: string;
  accentColor: string;
  glassmorphism: {
    enabled: boolean;
    blur: 'light' | 'medium' | 'heavy';
    opacity: number;
  };
}

export interface LanguageConfig {
  code: 'en' | 'ar';
  direction: 'ltr' | 'rtl';
  name: string;
  nativeName: string;
}

// Error handling types
export interface ApiError {
  message: string;
  code?: string;
  details?: any;
  timestamp: Date;
}

export interface ValidationError {
  field: string;
  message: string;
  value?: any;
}

// Pagination types
export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
}

// Search and filter types
export interface SearchFilters {
  query?: string;
  dateFrom?: Date;
  dateTo?: Date;
  status?: string[];
  assignedTo?: string[];
  priority?: string[];
  tags?: string[];
}

export interface SortConfig {
  field: string;
  direction: 'asc' | 'desc';
}

// Workspace and team management types
export interface WorkspaceSettings {
  name: string;
  description?: string;
  logoUrl?: string;
  timeZone: string;
  workingHours: {
    start: string;
    end: string;
    days: number[]; // 0-6, Sunday to Saturday
  };
  features: {
    timeTracking: boolean;
    attendanceTracking: boolean;
    reportGeneration: boolean;
    clientPortal: boolean;
  };
}

export interface TeamMember {
  user: User;
  role: string;
  joinedAt: Date;
  permissions: string[];
  status: 'active' | 'inactive' | 'pending';
}

// Client portal types
export interface ClientProject {
  project: Project;
  tasks: Task[];
  progress: number;
  timeline: {
    milestones: Array<{
      id: string;
      title: string;
      dueDate: Date;
      status: 'pending' | 'in_progress' | 'completed';
    }>;
  };
  updates: Array<{
    id: string;
    title: string;
    content: string;
    createdAt: Date;
    author: string;
  }>;
}

// Export commonly used type unions
export type UserRole = User['role'];
export type TaskStatus = Task['status'];
export type AttendanceStatus = Attendance['status'];
export type MessageType = Message['messageType'];
export type NotificationType = Notification['type'];
