import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import type { User } from "@shared/schema";
import { Sidebar } from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { TeamTasksWidget } from "@/components/dashboard/team-tasks-widget";
import { AttendanceWidget } from "@/components/dashboard/attendance-widget";
import { ReportsWidget } from "@/components/dashboard/reports-widget";
import { PerformanceWidget } from "@/components/dashboard/performance-widget";
import { QuickActionsWidget } from "@/components/dashboard/quick-actions-widget";
import { ActivityWidget } from "@/components/dashboard/activity-widget";
import { FloatingTimer } from "@/components/ui/floating-timer";
import { ChatWidget } from "@/components/ui/chat-widget";
import { NotificationPanel } from "@/components/ui/notification-panel";
import { WorkspaceInitialization } from "@/components/workspace-initialization";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showChat, setShowChat] = useState(false);

  const { data: dashboardData, isLoading: isDashboardLoading, error } = useQuery({
    queryKey: ["/api/dashboard"],
    enabled: isAuthenticated && !!user,
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  useEffect(() => {
    if (error && isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [error, toast]);

  if (isLoading || isDashboardLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-800">
        <div className="flex h-screen">
          <div className="w-64 glass rounded-r-2xl m-4 mr-0 p-6">
            <Skeleton className="h-10 w-full mb-4" />
            <Skeleton className="h-8 w-full mb-2" />
            <Skeleton className="h-8 w-full mb-2" />
            <Skeleton className="h-8 w-full mb-2" />
          </div>
          <div className="flex-1 p-4">
            <Skeleton className="h-20 w-full mb-6" />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              <Skeleton className="h-64 w-full" />
              <Skeleton className="h-64 w-full" />
              <Skeleton className="h-64 w-full" />
              <Skeleton className="h-64 w-full" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  // Type assertion for user to ensure proper typing
  const typedUser = user as User;
  const role = typedUser.role || 'employee';
  
  // Provide default empty data structure if dashboardData is not loaded yet
  const data = (dashboardData as any) || {
    teamTasks: { tasks: [] },
    teamAttendance: { attendance: [] },
    teamReports: { reports: [] },
    personalTasks: { tasks: [] },
    attendance: null,
    dailyReport: null
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-800">
      <WorkspaceInitialization />
      <div className="flex h-screen overflow-hidden">
        <Sidebar 
          user={typedUser}
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
          onShowChat={() => setShowChat(!showChat)}
        />

        <main className="flex-1 overflow-auto p-4">
          <Header 
            user={typedUser}
            onShowNotifications={() => setShowNotifications(!showNotifications)}
          />

          {/* Dashboard Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {(role === 'team_leader' || role === 'supervisor') && (
              <>
                <TeamTasksWidget data={data.teamTasks} />
                <AttendanceWidget data={data.teamAttendance} />
                <ReportsWidget data={data.teamReports} />
                <PerformanceWidget />
                <QuickActionsWidget role={role} />
                <ActivityWidget />
              </>
            )}

            {role === 'employee' && (
              <>
                <TeamTasksWidget data={data.personalTasks} />
                <AttendanceWidget data={{ attendance: data.attendance ? [data.attendance] : [] }} />
                <ReportsWidget data={{ reports: data.dailyReport ? [data.dailyReport] : [] }} />
                <QuickActionsWidget role={role} />
              </>
            )}

            {role === 'hr' && (
              <>
                <AttendanceWidget data={data.teamAttendance} />
                <PerformanceWidget />
                <QuickActionsWidget role={role} />
                <ActivityWidget />
              </>
            )}

            {role === 'client' && (
              <>
                <div className="md:col-span-2">
                  <h3 className="text-lg font-semibold text-white mb-4">Project Progress</h3>
                  {/* Client-specific widgets will be implemented */}
                </div>
              </>
            )}
          </div>
        </main>
      </div>

      <FloatingTimer />
      
      {showChat && (
        <ChatWidget 
          onClose={() => setShowChat(false)}
          user={typedUser}
        />
      )}

      <NotificationPanel 
        isOpen={showNotifications}
        onClose={() => setShowNotifications(false)}
        userId={typedUser.id}
      />
    </div>
  );
}
