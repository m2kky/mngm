import { Button } from "@/components/ui/button";
import { GlassCard } from "@/components/ui/glass-card";
import { Zap, Users, Clock, BarChart3, MessageSquare, Shield } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-800">
      {/* Header */}
      <header className="p-6">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 glass rounded-xl flex items-center justify-center">
              <Zap className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white text-shadow">Workit.OS</h1>
              <p className="text-xs text-white/70">Marketing Hub</p>
            </div>
          </div>
          <Button 
            onClick={handleLogin}
            className="bg-primary hover:bg-primary/90 text-white"
          >
            Sign In
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <main className="max-w-6xl mx-auto px-6 py-12">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-bold text-white text-shadow mb-6">
            The Ultimate
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary"> Marketing Team </span>
            Workspace
          </h2>
          <p className="text-xl text-white/80 mb-8 max-w-3xl mx-auto">
            Unify your team's workflow with role-based dashboards, intelligent task management, 
            real-time collaboration, and comprehensive performance analytics.
          </p>
          <Button 
            onClick={handleLogin}
            size="lg"
            className="bg-primary hover:bg-primary/90 text-white px-8 py-4 text-lg"
          >
            Get Started Today
          </Button>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          <GlassCard className="p-6 hover:bg-white/10 transition-all duration-300 group">
            <div className="w-12 h-12 bg-primary/20 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <Users className="w-6 h-6 text-primary" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Role-Based Access</h3>
            <p className="text-white/70">
              Tailored dashboards for Team Leaders, Supervisors, Employees, HR, and Clients. 
              Each role gets exactly what they need.
            </p>
          </GlassCard>

          <GlassCard className="p-6 hover:bg-white/10 transition-all duration-300 group">
            <div className="w-12 h-12 bg-secondary/20 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <Clock className="w-6 h-6 text-secondary" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Smart Timer System</h3>
            <p className="text-white/70">
              Built-in Pomodoro timers, break reminders, and automatic time tracking. 
              Stay focused and productive all day.
            </p>
          </GlassCard>

          <GlassCard className="p-6 hover:bg-white/10 transition-all duration-300 group">
            <div className="w-12 h-12 bg-success/20 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <BarChart3 className="w-6 h-6 text-success" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Performance Analytics</h3>
            <p className="text-white/70">
              Real-time insights into team productivity, attendance patterns, 
              and project progress with AI-powered recommendations.
            </p>
          </GlassCard>

          <GlassCard className="p-6 hover:bg-white/10 transition-all duration-300 group">
            <div className="w-12 h-12 bg-warning/20 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <MessageSquare className="w-6 h-6 text-warning" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Team Collaboration</h3>
            <p className="text-white/70">
              Built-in chat, file sharing, and Notion-style pages. 
              Keep all your team communication in one place.
            </p>
          </GlassCard>

          <GlassCard className="p-6 hover:bg-white/10 transition-all duration-300 group">
            <div className="w-12 h-12 bg-error/20 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <Shield className="w-6 h-6 text-error" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Client Portal</h3>
            <p className="text-white/70">
              Dedicated client access to project updates, feedback systems, 
              and approval workflows. Keep clients in the loop.
            </p>
          </GlassCard>

          <GlassCard className="p-6 hover:bg-white/10 transition-all duration-300 group">
            <div className="w-12 h-12 bg-primary/20 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <Zap className="w-6 h-6 text-primary" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Mobile-First Design</h3>
            <p className="text-white/70">
              Beautiful glassmorphism UI that works seamlessly on all devices. 
              Manage your team from anywhere.
            </p>
          </GlassCard>
        </div>

        {/* How It Works */}
        <div className="text-center mb-16">
          <h3 className="text-3xl font-bold text-white text-shadow mb-8">How It Works</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-primary">1</span>
              </div>
              <h4 className="text-xl font-semibold text-white mb-2">Choose Your Role</h4>
              <p className="text-white/70">
                Sign up and select your role to get a customized dashboard 
                tailored to your responsibilities.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-secondary">2</span>
              </div>
              <h4 className="text-xl font-semibold text-white mb-2">Set Up Your Workspace</h4>
              <p className="text-white/70">
                Create or join a workspace, invite your team members, 
                and start organizing your projects.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-success/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-success">3</span>
              </div>
              <h4 className="text-xl font-semibold text-white mb-2">Start Collaborating</h4>
              <p className="text-white/70">
                Assign tasks, track time, submit reports, and collaborate 
                in real-time with your team.
              </p>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <GlassCard className="p-8 text-center">
          <h3 className="text-3xl font-bold text-white text-shadow mb-4">
            Ready to Transform Your Team's Productivity?
          </h3>
          <p className="text-xl text-white/80 mb-6">
            Join thousands of marketing teams already using Workit.OS to streamline their workflow.
          </p>
          <Button 
            onClick={handleLogin}
            size="lg"
            className="bg-primary hover:bg-primary/90 text-white px-8 py-4 text-lg"
          >
            Get Started for Free
          </Button>
        </GlassCard>
      </main>

      {/* Footer */}
      <footer className="text-center py-8 px-6">
        <p className="text-white/60">
          © 2024 Workit.OS. Empowering marketing teams worldwide.
        </p>
      </footer>
    </div>
  );
}
