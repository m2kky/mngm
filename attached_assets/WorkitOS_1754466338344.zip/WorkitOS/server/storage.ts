import {
  users,
  workspaces,
  teams,
  projects,
  tasks,
  attendance,
  dailyReports,
  evaluations,
  pages,
  files,
  messages,
  notifications,
  timers,
  type User,
  type UpsertUser,
  type Workspace,
  type Team,
  type Project,
  type Task,
  type Attendance,
  type DailyReport,
  type Evaluation,
  type Page,
  type File,
  type Message,
  type Notification,
  type Timer,
  type InsertWorkspace,
  type InsertTeam,
  type InsertProject,
  type InsertTask,
  type InsertAttendance,
  type InsertDailyReport,
  type InsertEvaluation,
  type InsertPage,
  type InsertFile,
  type InsertMessage,
  type InsertNotification,
  type InsertTimer,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, sql, count, avg, sum } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Workspace operations
  createWorkspace(workspace: InsertWorkspace): Promise<Workspace>;
  getWorkspace(id: string): Promise<Workspace | undefined>;
  getUserWorkspaces(userId: string): Promise<Workspace[]>;
  
  // Team operations
  createTeam(team: InsertTeam): Promise<Team>;
  getTeam(id: string): Promise<Team | undefined>;
  getWorkspaceTeams(workspaceId: string): Promise<Team[]>;
  
  // Task operations
  createTask(task: InsertTask): Promise<Task>;
  getTask(id: string): Promise<Task | undefined>;
  getUserTasks(userId: string, workspaceId: string): Promise<Task[]>;
  getTeamTasks(teamId: string): Promise<Task[]>;
  updateTaskStatus(taskId: string, status: string): Promise<Task>;
  
  // Attendance operations
  createAttendance(attendance: InsertAttendance): Promise<Attendance>;
  getUserAttendance(userId: string, date: string): Promise<Attendance | undefined>;
  getTeamAttendance(teamId: string, date: string): Promise<Attendance[]>;
  checkIn(userId: string, workspaceId: string): Promise<Attendance>;
  checkOut(userId: string, workspaceId: string): Promise<Attendance>;
  
  // Daily Report operations
  createDailyReport(report: InsertDailyReport): Promise<DailyReport>;
  getUserDailyReport(userId: string, date: string): Promise<DailyReport | undefined>;
  getTeamDailyReports(teamId: string, date: string): Promise<DailyReport[]>;
  
  // Timer operations
  createTimer(timer: InsertTimer): Promise<Timer>;
  getActiveTimer(userId: string): Promise<Timer | undefined>;
  stopTimer(timerId: string): Promise<Timer>;
  
  // Message operations
  createMessage(message: InsertMessage): Promise<Message>;
  getChannelMessages(channelId: string, channelType: string): Promise<Message[]>;
  
  // Notification operations
  createNotification(notification: InsertNotification): Promise<Notification>;
  getUserNotifications(userId: string): Promise<Notification[]>;
  markNotificationRead(notificationId: string): Promise<void>;
  
  // Dashboard data
  getDashboardData(userId: string, role: string, workspaceId: string): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Workspace operations
  async createWorkspace(workspace: InsertWorkspace): Promise<Workspace> {
    const [newWorkspace] = await db.insert(workspaces).values(workspace).returning();
    return newWorkspace;
  }

  async getWorkspace(id: string): Promise<Workspace | undefined> {
    const [workspace] = await db.select().from(workspaces).where(eq(workspaces.id, id));
    return workspace;
  }

  async getUserWorkspaces(userId: string): Promise<Workspace[]> {
    return await db
      .select()
      .from(workspaces)
      .where(eq(workspaces.createdBy, userId));
  }

  // Team operations
  async createTeam(team: InsertTeam): Promise<Team> {
    const [newTeam] = await db.insert(teams).values(team).returning();
    return newTeam;
  }

  async getTeam(id: string): Promise<Team | undefined> {
    const [team] = await db.select().from(teams).where(eq(teams.id, id));
    return team;
  }

  async getWorkspaceTeams(workspaceId: string): Promise<Team[]> {
    return await db
      .select()
      .from(teams)
      .where(eq(teams.workspaceId, workspaceId));
  }

  // Task operations
  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db.insert(tasks).values(task).returning();
    return newTask;
  }

  async getTask(id: string): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task;
  }

  async getUserTasks(userId: string, workspaceId: string): Promise<Task[]> {
    return await db
      .select()
      .from(tasks)
      .where(and(eq(tasks.assignedTo, userId), eq(tasks.workspaceId, workspaceId)))
      .orderBy(desc(tasks.createdAt));
  }

  async getTeamTasks(teamId: string): Promise<Task[]> {
    return await db
      .select()
      .from(tasks)
      .where(eq(tasks.teamId, teamId))
      .orderBy(desc(tasks.createdAt));
  }

  async updateTaskStatus(taskId: string, status: string): Promise<Task> {
    const [updatedTask] = await db
      .update(tasks)
      .set({ status: status as any, updatedAt: new Date() })
      .where(eq(tasks.id, taskId))
      .returning();
    return updatedTask;
  }

  // Attendance operations
  async createAttendance(attendanceData: InsertAttendance): Promise<Attendance> {
    const [newAttendance] = await db.insert(attendance).values(attendanceData).returning();
    return newAttendance;
  }

  async getUserAttendance(userId: string, date: string): Promise<Attendance | undefined> {
    const [attendanceRecord] = await db
      .select()
      .from(attendance)
      .where(and(eq(attendance.userId, userId), eq(attendance.date, date)));
    return attendanceRecord;
  }

  async getTeamAttendance(teamId: string, date: string): Promise<Attendance[]> {
    return await db
      .select({
        id: attendance.id,
        userId: attendance.userId,
        workspaceId: attendance.workspaceId,
        date: attendance.date,
        checkIn: attendance.checkIn,
        checkOut: attendance.checkOut,
        status: attendance.status,
        notes: attendance.notes,
        hoursWorked: attendance.hoursWorked,
        createdAt: attendance.createdAt,
        updatedAt: attendance.updatedAt,
      })
      .from(attendance)
      .innerJoin(users, eq(users.id, attendance.userId))
      .where(and(eq(users.teamId, teamId), eq(attendance.date, date)));
  }

  async checkIn(userId: string, workspaceId: string): Promise<Attendance> {
    const today = new Date().toISOString().split('T')[0];
    const checkInTime = new Date();
    
    // Check if attendance record exists for today
    const existing = await this.getUserAttendance(userId, today);
    
    if (existing) {
      // Update existing record
      const [updated] = await db
        .update(attendance)
        .set({ checkIn: checkInTime, status: 'present', updatedAt: new Date() })
        .where(eq(attendance.id, existing.id))
        .returning();
      return updated;
    } else {
      // Create new record
      return await this.createAttendance({
        userId,
        workspaceId,
        date: today,
        checkIn: checkInTime,
        status: 'present',
      });
    }
  }

  async checkOut(userId: string, workspaceId: string): Promise<Attendance> {
    const today = new Date().toISOString().split('T')[0];
    const checkOutTime = new Date();
    
    const existing = await this.getUserAttendance(userId, today);
    if (!existing) {
      throw new Error('No check-in record found for today');
    }

    // Calculate hours worked
    const hoursWorked = existing.checkIn 
      ? Math.round((checkOutTime.getTime() - existing.checkIn.getTime()) / (1000 * 60))
      : 0;

    const [updated] = await db
      .update(attendance)
      .set({ 
        checkOut: checkOutTime, 
        hoursWorked,
        updatedAt: new Date() 
      })
      .where(eq(attendance.id, existing.id))
      .returning();
    
    return updated;
  }

  // Daily Report operations
  async createDailyReport(report: InsertDailyReport): Promise<DailyReport> {
    const [newReport] = await db.insert(dailyReports).values(report).returning();
    return newReport;
  }

  async getUserDailyReport(userId: string, date: string): Promise<DailyReport | undefined> {
    const [report] = await db
      .select()
      .from(dailyReports)
      .where(and(eq(dailyReports.userId, userId), eq(dailyReports.date, date)));
    return report;
  }

  async getTeamDailyReports(teamId: string, date: string): Promise<DailyReport[]> {
    return await db
      .select({
        id: dailyReports.id,
        userId: dailyReports.userId,
        workspaceId: dailyReports.workspaceId,
        date: dailyReports.date,
        content: dailyReports.content,
        mood: dailyReports.mood,
        tasksCompleted: dailyReports.tasksCompleted,
        hoursWorked: dailyReports.hoursWorked,
        challenges: dailyReports.challenges,
        achievements: dailyReports.achievements,
        aiSummary: dailyReports.aiSummary,
        createdAt: dailyReports.createdAt,
        updatedAt: dailyReports.updatedAt,
      })
      .from(dailyReports)
      .innerJoin(users, eq(users.id, dailyReports.userId))
      .where(and(eq(users.teamId, teamId), eq(dailyReports.date, date)));
  }

  // Timer operations
  async createTimer(timer: InsertTimer): Promise<Timer> {
    const [newTimer] = await db.insert(timers).values(timer).returning();
    return newTimer;
  }

  async getActiveTimer(userId: string): Promise<Timer | undefined> {
    const [timer] = await db
      .select()
      .from(timers)
      .where(and(eq(timers.userId, userId), eq(timers.isActive, true)))
      .orderBy(desc(timers.createdAt))
      .limit(1);
    return timer;
  }

  async stopTimer(timerId: string): Promise<Timer> {
    const endTime = new Date();
    const [existing] = await db.select().from(timers).where(eq(timers.id, timerId));
    
    if (!existing) {
      throw new Error('Timer not found');
    }

    const duration = Math.round((endTime.getTime() - existing.startTime.getTime()) / 1000);

    const [updated] = await db
      .update(timers)
      .set({ 
        endTime, 
        duration, 
        isActive: false,
        updatedAt: new Date() 
      })
      .where(eq(timers.id, timerId))
      .returning();
    
    return updated;
  }

  // Message operations
  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db.insert(messages).values(message).returning();
    return newMessage;
  }

  async getChannelMessages(channelId: string, channelType: string): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(and(eq(messages.channelId, channelId), eq(messages.channelType, channelType)))
      .orderBy(desc(messages.createdAt))
      .limit(50);
  }

  // Notification operations
  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db.insert(notifications).values(notification).returning();
    return newNotification;
  }

  async getUserNotifications(userId: string): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt))
      .limit(20);
  }

  async markNotificationRead(notificationId: string): Promise<void> {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, notificationId));
  }

  // Dashboard data aggregation
  async getDashboardData(userId: string, role: string, workspaceId: string): Promise<any> {
    const today = new Date().toISOString().split('T')[0];
    const user = await this.getUser(userId);
    
    if (!user) {
      throw new Error('User not found');
    }

    const result: any = {
      user,
      workspace: await this.getWorkspace(workspaceId),
    };

    try {
      if (role === 'employee') {
        // Employee dashboard data
        const personalTasks = await this.getUserTasks(userId, workspaceId);
        const userAttendance = await this.getUserAttendance(userId, today);
        const userReport = await this.getUserDailyReport(userId, today);

        result.personalTasks = {
          tasks: personalTasks,
          total: personalTasks.length,
          completed: personalTasks.filter(t => t.status === 'done').length,
          inProgress: personalTasks.filter(t => t.status === 'in_progress').length,
          overdue: personalTasks.filter(t => 
            t.dueDate && new Date(t.dueDate) < new Date() && t.status !== 'done'
          ).length,
        };

        result.attendance = userAttendance;
        result.dailyReport = userReport;

      } else if (role === 'team_leader' || role === 'supervisor' || role === 'hr') {
        // Team/supervisor dashboard data
        if (user.teamId) {
          const teamTasks = await this.getTeamTasks(user.teamId);
          const teamAttendanceList = await this.getTeamAttendance(user.teamId, today);
          const teamReports = await this.getTeamDailyReports(user.teamId, today);

          result.teamTasks = {
            tasks: teamTasks,
            total: teamTasks.length,
            completed: teamTasks.filter(t => t.status === 'done').length,
            inProgress: teamTasks.filter(t => t.status === 'in_progress').length,
            overdue: teamTasks.filter(t => 
              t.dueDate && new Date(t.dueDate) < new Date() && t.status !== 'done'
            ).length,
          };

          result.teamAttendance = {
            attendance: teamAttendanceList,
            total: teamAttendanceList.length,
            present: teamAttendanceList.filter(a => a.status === 'present').length,
            late: teamAttendanceList.filter(a => a.status === 'late').length,
            absent: teamAttendanceList.filter(a => a.status === 'absent').length,
          };

          result.teamReports = {
            reports: teamReports,
            submitted: teamReports.length,
            pending: 0, // Calculate based on team size vs submitted reports
          };
        }

        // Personal data for managers
        const personalTasks = await this.getUserTasks(userId, workspaceId);
        result.personalTasks = {
          tasks: personalTasks,
          total: personalTasks.length,
          completed: personalTasks.filter(t => t.status === 'done').length,
          inProgress: personalTasks.filter(t => t.status === 'in_progress').length,
          overdue: personalTasks.filter(t => 
            t.dueDate && new Date(t.dueDate) < new Date() && t.status !== 'done'
          ).length,
        };
      }

      // Get recent activity for all roles
      const recentNotifications = await this.getUserNotifications(userId);
      result.recentActivity = recentNotifications.slice(0, 5);

      return result;
    } catch (error) {
      console.error('Error getting dashboard data:', error);
      // Return empty structure on error
      return {
        user,
        workspace: await this.getWorkspace(workspaceId),
        personalTasks: { tasks: [], total: 0, completed: 0, inProgress: 0, overdue: 0 },
        teamTasks: { tasks: [], total: 0, completed: 0, inProgress: 0, overdue: 0 },
        teamAttendance: { attendance: [], total: 0, present: 0, late: 0, absent: 0 },
        teamReports: { reports: [], submitted: 0, pending: 0 },
        attendance: null,
        dailyReport: null,
        recentActivity: [],
      };
    }
  }
}

export const storage = new DatabaseStorage();
