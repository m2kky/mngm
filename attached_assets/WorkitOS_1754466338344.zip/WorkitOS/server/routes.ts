import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { 
  insertTaskSchema, 
  insertAttendanceSchema, 
  insertDailyReportSchema,
  insertMessageSchema,
  insertNotificationSchema,
  insertTimerSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Dashboard data
  app.get('/api/dashboard', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const dashboardData = await storage.getDashboardData(userId, user.role, user.workspaceId!);
      res.json(dashboardData);
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
      res.status(500).json({ message: "Failed to fetch dashboard data" });
    }
  });

  // Task routes
  app.post('/api/tasks', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const taskData = insertTaskSchema.parse({
        ...req.body,
        assignedBy: userId,
        workspaceId: user.workspaceId,
        teamId: user.teamId,
      });

      const task = await storage.createTask(taskData);
      
      // Create notification for assignee
      if (taskData.assignedTo !== userId) {
        await storage.createNotification({
          userId: taskData.assignedTo,
          workspaceId: user.workspaceId!,
          title: "New Task Assigned",
          message: `You have been assigned a new task: ${taskData.title}`,
          type: "task",
          relatedId: task.id,
          relatedType: "task",
        });
      }

      res.json(task);
    } catch (error) {
      console.error("Error creating task:", error);
      res.status(500).json({ message: "Failed to create task" });
    }
  });

  app.get('/api/tasks/my', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const tasks = await storage.getUserTasks(userId, user.workspaceId!);
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching user tasks:", error);
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  app.put('/api/tasks/:id/status', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      
      const task = await storage.updateTaskStatus(id, status);
      res.json(task);
    } catch (error) {
      console.error("Error updating task status:", error);
      res.status(500).json({ message: "Failed to update task status" });
    }
  });

  // Attendance routes
  app.post('/api/attendance/check-in', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const attendance = await storage.checkIn(userId, user.workspaceId!);
      res.json(attendance);
    } catch (error) {
      console.error("Error checking in:", error);
      res.status(500).json({ message: "Failed to check in" });
    }
  });

  app.post('/api/attendance/check-out', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const attendance = await storage.checkOut(userId, user.workspaceId!);
      res.json(attendance);
    } catch (error) {
      console.error("Error checking out:", error);
      res.status(500).json({ message: "Failed to check out" });
    }
  });

  // Daily Report routes
  app.post('/api/reports', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const reportData = insertDailyReportSchema.parse({
        ...req.body,
        userId,
        workspaceId: user.workspaceId,
        date: new Date().toISOString().split('T')[0],
      });

      const report = await storage.createDailyReport(reportData);
      res.json(report);
    } catch (error) {
      console.error("Error submitting report:", error);
      res.status(500).json({ message: "Failed to submit report" });
    }
  });

  // Timer routes
  app.post('/api/timers/start', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const { taskId } = req.body;
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Stop any active timer first
      const activeTimer = await storage.getActiveTimer(userId);
      if (activeTimer) {
        await storage.stopTimer(activeTimer.id);
      }

      const timerData = insertTimerSchema.parse({
        userId,
        taskId,
        workspaceId: user.workspaceId!,
        startTime: new Date(),
      });

      const timer = await storage.createTimer(timerData);
      res.json(timer);
    } catch (error) {
      console.error("Error starting timer:", error);
      res.status(500).json({ message: "Failed to start timer" });
    }
  });

  app.post('/api/timers/:id/stop', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const timer = await storage.stopTimer(id);
      res.json(timer);
    } catch (error) {
      console.error("Error stopping timer:", error);
      res.status(500).json({ message: "Failed to stop timer" });
    }
  });

  app.get('/api/timers/active', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const timer = await storage.getActiveTimer(userId);
      res.json(timer || null);
    } catch (error) {
      console.error("Error fetching active timer:", error);
      res.status(500).json({ message: "Failed to fetch active timer" });
    }
  });

  // Messages/Chat routes
  app.post('/api/messages', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const messageData = insertMessageSchema.parse({
        ...req.body,
        senderId: userId,
        workspaceId: user.workspaceId,
      });

      const message = await storage.createMessage(messageData);
      
      // Note: WebSocket broadcasting is handled in the WebSocket section below
      
      res.json(message);
    } catch (error) {
      console.error("Error sending message:", error);
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  app.get('/api/messages/:channelId', isAuthenticated, async (req: any, res) => {
    try {
      const { channelId } = req.params;
      const { channelType = 'team' } = req.query;
      
      const messages = await storage.getChannelMessages(channelId, channelType);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Notifications routes
  app.get('/api/notifications', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const notifications = await storage.getUserNotifications(userId);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.post('/api/notifications/:id/read', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      await storage.markNotificationRead(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  // Initialize demo workspace and team for new users
  app.post('/api/initialize-workspace', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Check if user already has a workspace
      if (user.workspaceId) {
        return res.json({ message: "User already has a workspace" });
      }

      // Create demo workspace
      const workspace = await storage.createWorkspace({
        name: "مكتب العمل الرقمي",
        slug: `workspace-${userId}`,
        createdBy: userId,
      });

      // Create demo team
      const team = await storage.createTeam({
        name: "فريق التسويق",
        description: "فريق التسويق الرقمي",
        workspaceId: workspace.id,
        createdBy: userId,
      });

      // Update user with workspace and team
      await storage.upsertUser({
        id: userId,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        profileImageUrl: user.profileImageUrl,
        workspaceId: workspace.id,
        teamId: team.id,
      });

      res.json({ workspace, team });
    } catch (error) {
      console.error("Error initializing workspace:", error);
      res.status(500).json({ message: "Failed to initialize workspace" });
    }
  });

  // Chat routes
  app.get('/api/chat/:channelId/:channelType', isAuthenticated, async (req: any, res) => {
    try {
      const { channelId, channelType } = req.params;
      const messages = await storage.getChannelMessages(channelId, channelType);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Notification routes
  app.get('/api/notifications', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const notifications = await storage.getUserNotifications(userId);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.put('/api/notifications/:id/read', isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      await storage.markNotificationRead(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  const httpServer = createServer(app);

  // WebSocket setup
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws: WebSocket, req) => {
    console.log('WebSocket connection established');

    ws.on('message', async (message: string) => {
      try {
        const data = JSON.parse(message);
        
        if (data.type === 'chat_message') {
          // Handle chat message
          const messageData = insertMessageSchema.parse({
            senderId: data.senderId,
            workspaceId: data.workspaceId,
            channelId: data.channelId,
            channelType: data.channelType,
            content: data.content,
            messageType: 'text',
          });

          const newMessage = await storage.createMessage(messageData);
          
          // Broadcast to all connected clients
          wss.clients.forEach(client => {
            if (client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify({
                type: 'chat_message',
                message: newMessage,
              }));
            }
          });
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      console.log('WebSocket connection closed');
    });
  });

  return httpServer;
}
