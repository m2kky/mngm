# Workit.OS - Marketing Team Management Platform

## Overview

Workit.OS is a comprehensive workspace management platform designed specifically for marketing teams and agencies. The application provides a unified dashboard experience with role-based interfaces for team leaders, supervisors, employees, HR staff, and clients. Built as a modern web application with a glassmorphism design aesthetic, it combines task management, attendance tracking, performance analytics, real-time collaboration, and client portal functionality in a single platform.

The system emphasizes mobile-first design principles while maintaining full desktop functionality, making it suitable for distributed teams and on-the-go marketing professionals.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The client-side application is built using React with TypeScript, implementing a modern component-based architecture. The UI framework leverages Radix UI primitives with a custom glassmorphism design system built on Tailwind CSS. The application uses Wouter for lightweight routing and TanStack Query for efficient server state management with optimistic updates and caching.

The design system emphasizes visual hierarchy through glass cards, backdrop blur effects, and CSS custom properties for theming. Components are organized into reusable UI primitives, layout components, and feature-specific widgets that adapt based on user roles.

### Backend Architecture
The server implements a REST API using Express.js with TypeScript in ESM format. The architecture follows a layered approach with route handlers, business logic in storage services, and database operations through Drizzle ORM. The system includes WebSocket support for real-time features like chat and live notifications.

Authentication is handled through Replit's OpenID Connect integration with session management using PostgreSQL-backed storage. The API design emphasizes RESTful principles with consistent error handling and response formats.

### Database Design
The application uses PostgreSQL as the primary database with Drizzle ORM for type-safe database operations. The schema implements a multi-tenant architecture centered around workspaces, with users belonging to teams within workspaces. 

Key entities include users with role-based permissions, tasks with status tracking and timer integration, attendance records with check-in/out functionality, daily reports with mood tracking, and real-time messaging capabilities. The schema supports file management with visibility controls and notification systems for team coordination.

### Real-time Communication
WebSocket integration enables live features including team chat with channel-based messaging, real-time task updates and status changes, attendance notifications, and system-wide notifications. The client maintains persistent connections with automatic reconnection handling and message queuing during disconnections.

### Role-Based Access Control
The system implements comprehensive role-based permissions with distinct interfaces for each user type. Team leaders access comprehensive analytics and team management tools, supervisors handle task distribution and progress monitoring, employees focus on personal productivity with timer integration, HR staff manage attendance analytics and team wellness metrics, and clients view project progress through dedicated portals.

### State Management Strategy
Client-side state management combines TanStack Query for server state with local React state for UI interactions. The architecture emphasizes optimistic updates for improved user experience, with automatic background synchronization and conflict resolution. Query invalidation strategies ensure data consistency across real-time updates.

### Mobile-First Design
The interface prioritizes mobile usability while scaling effectively to desktop resolutions. Touch-friendly interactions, responsive layouts using CSS Grid and Flexbox, and progressive enhancement ensure functionality across device types. The glassmorphism design adapts gracefully to different screen sizes and input methods.

## External Dependencies

### Database and ORM
- **PostgreSQL** via Neon Database for primary data storage with connection pooling
- **Drizzle ORM** for type-safe database operations and schema migrations
- **connect-pg-simple** for PostgreSQL-backed session storage

### Authentication and Security
- **Replit Authentication** using OpenID Connect for user authentication
- **Express Session** with PostgreSQL store for session management
- **Passport.js** with OpenID strategy for authentication middleware

### Frontend Framework and UI
- **React 18** with TypeScript for component-based UI development
- **Radix UI** component primitives for accessible and customizable UI elements
- **Tailwind CSS** for utility-first styling with custom design system
- **Lucide React** for consistent iconography throughout the application

### Development and Build Tools
- **Vite** for fast development server and optimized production builds
- **TypeScript** for type safety across the entire application stack
- **ESBuild** for efficient server-side bundling and transpilation

### Real-time and Communication
- **WebSocket (ws)** for real-time bidirectional communication
- **TanStack Query** for server state management with real-time synchronization

### Utility Libraries
- **date-fns** for comprehensive date manipulation and formatting
- **class-variance-authority** for type-safe CSS class composition
- **zod** with drizzle-zod for runtime schema validation